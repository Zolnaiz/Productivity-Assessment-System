import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:3000/api';

class ApiService {
  private axiosInstance: AxiosInstance;
  private refreshTokenPromise: Promise<string> | null = null;

  constructor() {
    this.axiosInstance = axios.create({
      baseURL: API_URL,
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    this.setupInterceptors();
  }

  private setupInterceptors(): void {
    // Request interceptor
    this.axiosInstance.interceptors.request.use(
      (config) => {
        const token = localStorage.getItem('access_token');
        if (token && config.headers) {
          config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
      },
      (error) => Promise.reject(error)
    );

    // Response interceptor
    this.axiosInstance.interceptors.response.use(
      (response) => response,
      async (error) => {
        const originalRequest = error.config;

        if (error.response?.status === 401 && !originalRequest._retry) {
          originalRequest._retry = true;

          try {
            const newAccessToken = await this.refreshAccessToken();
            if (newAccessToken) {
              localStorage.setItem('access_token', newAccessToken);
              originalRequest.headers.Authorization = `Bearer ${newAccessToken}`;
              return this.axiosInstance(originalRequest);
            }
          } catch (refreshError) {
            this.clearAuth();
            window.location.href = '/login';
            return Promise.reject(refreshError);
          }
        }

        return Promise.reject(error);
      }
    );
  }

  private async refreshAccessToken(): Promise<string> {
    if (this.refreshTokenPromise) {
      return this.refreshTokenPromise;
    }

    this.refreshTokenPromise = new Promise(async (resolve, reject) => {
      try {
        const refreshToken = localStorage.getItem('refresh_token');
        if (!refreshToken) {
          throw new Error('No refresh token');
        }

        const response = await axios.post(`${API_URL}/auth/refresh`, {
          refresh_token: refreshToken,
        });

        const { access_token } = response.data;
        resolve(access_token);
      } catch (error) {
        reject(error);
      } finally {
        this.refreshTokenPromise = null;
      }
    });

    return this.refreshTokenPromise;
  }

  private clearAuth(): void {
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');
    localStorage.removeItem('user');
  }

  // Auth methods
  async login(email: string, password: string): Promise<any> {
    const response = await this.axiosInstance.post('/auth/login', {
      email,
      password,
    });

    const { access_token, refresh_token, user } = response.data;
    
    localStorage.setItem('access_token', access_token);
    localStorage.setItem('refresh_token', refresh_token);
    localStorage.setItem('user', JSON.stringify(user));

    return user;
  }

  async logout(): Promise<void> {
    try {
      await this.axiosInstance.post('/auth/logout');
    } finally {
      this.clearAuth();
    }
  }

  async getCurrentUser(): Promise<any> {
    const userStr = localStorage.getItem('user');
    if (userStr) {
      return JSON.parse(userStr);
    }
    
    const response = await this.axiosInstance.get('/auth/profile');
    return response.data;
  }

  // Organizations
  async getOrganizations(params?: any): Promise<any> {
    const response = await this.axiosInstance.get('/organizations', { params });
    return response.data;
  }

  async getOrganization(id: string): Promise<any> {
    const response = await this.axiosInstance.get(`/organizations/${id}`);
    return response.data;
  }

  async createOrganization(data: any): Promise<any> {
    const response = await this.axiosInstance.post('/organizations', data);
    return response.data;
  }

  async updateOrganization(id: string, data: any): Promise<any> {
    const response = await this.axiosInstance.put(`/organizations/${id}`, data);
    return response.data;
  }

  async deleteOrganization(id: string): Promise<void> {
    await this.axiosInstance.delete(`/organizations/${id}`);
  }

  // Questionnaires
  async getQuestionnaires(params?: any): Promise<any> {
    const response = await this.axiosInstance.get('/questionnaires', { params });
    return response.data;
  }

  async getQuestionnaire(id: string): Promise<any> {
    const response = await this.axiosInstance.get(`/questionnaires/${id}`);
    return response.data;
  }

  async createQuestionnaire(data: any): Promise<any> {
    const response = await this.axiosInstance.post('/questionnaires', data);
    return response.data;
  }

  // Responses
  async getResponses(params?: any): Promise<any> {
    const response = await this.axiosInstance.get('/responses', { params });
    return response.data;
  }

  async getResponseStats(): Promise<any> {
    const response = await this.axiosInstance.get('/responses/stats');
    return response.data;
  }

  // Expenses
  async getExpenses(params?: any): Promise<any> {
    const response = await this.axiosInstance.get('/expenses', { params });
    return response.data;
  }

  async getExpenseSummary(): Promise<any> {
    const response = await this.axiosInstance.get('/expenses/summary');
    return response.data;
  }

  // Reports
  async generateReport(data: any): Promise<any> {
    const response = await this.axiosInstance.post('/reports/generate', data);
    return response.data;
  }

  async getReportTemplates(): Promise<any> {
    const response = await this.axiosInstance.get('/reports/templates');
    return response.data;
  }

  // Generic request method
  async request<T = any>(config: AxiosRequestConfig): Promise<T> {
    const response: AxiosResponse<T> = await this.axiosInstance.request(config);
    return response.data;
  }
}

export const apiService = new ApiService();
export default apiService;