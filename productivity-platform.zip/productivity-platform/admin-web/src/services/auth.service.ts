import { authAPI } from './api';
import toast from 'react-hot-toast';

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface AuthResponse {
  access_token: string;
  user: {
    id: number;
    email: string;
    full_name: string;
    role: string;
    organization_id: number | null;
    phone_number?: string;
    position?: string;
  };
  expires_in?: string;
}

class AuthService {
  private tokenKey = 'admin_token';
  private userKey = 'admin_user';

  async login(credentials: LoginCredentials): Promise<AuthResponse> {
    try {
      const response = await authAPI.login(credentials.email, credentials.password);
      const data = response.data;
      
      if (data.user.role !== 'superadmin') {
        throw new Error('Зөвхөн систем админд нэвтрэх боломжтой');
      }
      
      // Store token and user info
      localStorage.setItem(this.tokenKey, data.access_token);
      localStorage.setItem(this.userKey, JSON.stringify(data.user));
      
      toast.success('Амжилттай нэвтэрлээ');
      return data;
    } catch (error: any) {
      if (error.response?.status === 401) {
        throw new Error('Нэвтрэх нэр эсвэл нууц үг буруу байна');
      }
      throw error;
    }
  }

  logout(): void {
    authAPI.logout().catch(() => {
      // Ignore errors during logout
    });
    
    localStorage.removeItem(this.tokenKey);
    localStorage.removeItem(this.userKey);
    toast.success('Амжилттай гарлаа');
  }

  getToken(): string | null {
    return localStorage.getItem(this.tokenKey);
  }

  getUser(): any {
    const userStr = localStorage.getItem(this.userKey);
    return userStr ? JSON.parse(userStr) : null;
  }

  isAuthenticated(): boolean {
    return !!this.getToken();
  }

  isSuperAdmin(): boolean {
    const user = this.getUser();
    return user?.role === 'superadmin';
  }

  // Superadmin login helper
  async superadminLogin(): Promise<AuthResponse> {
    return this.login({
      email: 'superadmin@productivity.mn',
      password: 'Admin123!'
    });
  }

  // Demo organization admin login helper
  async demoLogin(): Promise<AuthResponse> {
    return this.login({
      email: 'demo@company.mn',
      password: 'Demo123!'
    });
  }

  async refreshProfile(): Promise<void> {
    try {
      const response = await authAPI.getProfile();
      localStorage.setItem(this.userKey, JSON.stringify(response.data));
    } catch (error) {
      console.error('Failed to refresh profile:', error);
    }
  }
}

export default new AuthService();