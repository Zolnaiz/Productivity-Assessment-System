import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Container,
  Paper,
  TextField,
  Button,
  Typography,
  Box,
  Alert,
  CircularProgress,
  Grid,
  Card,
  CardContent,
  Divider,
} from '@mui/material';
import { LockOutlined, Business, Assessment, TrendingUp } from '@mui/icons-material';
import { useAuth } from '../contexts/AuthContext';

const LoginPage: React.FC = () => {
  const navigate = useNavigate();
  const { login, loading, error, clearError } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    
    try {
      await login(email, password);
    } catch (err) {
      // Error is handled by auth context
    }
  };

  const handleSuperadminLogin = async () => {
    clearError();
    try {
      await login('superadmin@productivity.mn', 'Admin123!');
    } catch (err) {
      // Error is handled by auth context
    }
  };

  const features = [
    {
      icon: <Business fontSize="large" />,
      title: 'Байгууллагын удирдлага',
      description: 'Бүх байгууллагын мэдээлэл, статистикийг нэг дороос удирдах',
    },
    {
      icon: <Assessment fontSize="large" />,
      title: 'Дэлгэрэнгүй шинжилгээ',
      description: 'Байгууллагын бүтээмжийн гүнзгий шинжилгээ, тайлан',
    },
    {
      icon: <TrendingUp fontSize="large" />,
      title: 'Хөгжлийн мониторинг',
      description: 'Байгууллагын хөгжлийн чиг хандлагыг хянах',
    },
  ];

  return (
    <Box sx={{ 
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      display: 'flex',
      alignItems: 'center',
      py: 4,
    }}>
      <Container maxWidth="lg">
        <Grid container spacing={4}>
          <Grid item xs={12} md={6}>
            <Paper
              elevation={6}
              sx={{
                padding: 4,
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                borderRadius: 2,
              }}
            >
              <LockOutlined sx={{ fontSize: 40, mb: 2, color: 'primary.main' }} />
              <Typography component="h1" variant="h4" gutterBottom>
                Admin Portal
              </Typography>
              <Typography variant="body2" color="textSecondary" sx={{ mb: 3, textAlign: 'center' }}>
                Productivity Platform - Системийн админ
              </Typography>

              <Box component="form" onSubmit={handleSubmit} sx={{ mt: 1, width: '100%' }}>
                {error && (
                  <Alert severity="error" sx={{ mb: 2 }} onClose={clearError}>
                    {error}
                  </Alert>
                )}
                
                <TextField
                  margin="normal"
                  required
                  fullWidth
                  label="Имэйл хаяг"
                  autoComplete="email"
                  autoFocus
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  disabled={loading}
                  sx={{ mb: 2 }}
                />
                <TextField
                  margin="normal"
                  required
                  fullWidth
                  label="Нууц үг"
                  type="password"
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  disabled={loading}
                  sx={{ mb: 3 }}
                />
                
                <Button
                  type="submit"
                  fullWidth
                  variant="contained"
                  size="large"
                  disabled={loading}
                  sx={{ mb: 2 }}
                >
                  {loading ? <CircularProgress size={24} /> : 'Нэвтрэх'}
                </Button>
                
                <Divider sx={{ my: 2 }}>
                  <Typography variant="body2" color="text.secondary">
                    Эсвэл
                  </Typography>
                </Divider>
                
                <Button
                  fullWidth
                  variant="outlined"
                  size="large"
                  onClick={handleSuperadminLogin}
                  disabled={loading}
                >
                  Супер админаар нэвтрэх
                </Button>
              </Box>
            </Paper>
          </Grid>
          
          <Grid item xs={12} md={6}>
            <Box sx={{ color: 'white', height: '100%' }}>
              <Typography variant="h3" gutterBottom sx={{ fontWeight: 'bold', mb: 3 }}>
                Productivity Platform
              </Typography>
              <Typography variant="h6" sx={{ mb: 4, opacity: 0.9 }}>
                Байгууллагын бүтээмжийг үнэлэх, хэмжих, хөгжүүлэх цогц платформын системийн удирдлага
              </Typography>
              
              <Grid container spacing={3}>
                {features.map((feature, index) => (
                  <Grid item xs={12} key={index}>
                    <Card sx={{ 
                      backgroundColor: 'rgba(255, 255, 255, 0.1)',
                      backdropFilter: 'blur(10px)',
                      border: '1px solid rgba(255, 255, 255, 0.2)',
                    }}>
                      <CardContent>
                        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                          <Box sx={{ mr: 2, color: 'white' }}>
                            {feature.icon}
                          </Box>
                          <Typography variant="h6" sx={{ color: 'white', fontWeight: 'bold' }}>
                            {feature.title}
                          </Typography>
                        </Box>
                        <Typography variant="body2" sx={{ color: 'rgba(255, 255, 255, 0.8)' }}>
                          {feature.description}
                        </Typography>
                      </CardContent>
                    </Card>
                  </Grid>
                ))}
              </Grid>
              
              <Box sx={{ mt: 4 }}>
                <Typography variant="body2" sx={{ color: 'rgba(255, 255, 255, 0.7)' }}>
                  <strong>Супер админ эрх:</strong> superadmin@productivity.mn / Admin123!
                </Typography>
                <Typography variant="body2" sx={{ color: 'rgba(255, 255, 255, 0.7)', mt: 1 }}>
                  <strong>Demo эрх:</strong> demo@company.mn / Demo123!
                </Typography>
              </Box>
            </Box>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
};

export default LoginPage;