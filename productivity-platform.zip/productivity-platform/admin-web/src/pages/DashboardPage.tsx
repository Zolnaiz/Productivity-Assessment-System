import React, { useState, useEffect } from 'react';
import {
  Grid,
  Paper,
  Typography,
  Box,
  Card,
  CardContent,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  CircularProgress,
  Alert,
  Chip,
  LinearProgress,
  IconButton,
} from '@mui/material';
import {
  Assessment,
  TrendingUp,
  People,
  Business,
  ShowChart,
  Refresh,
  ArrowUpward,
  ArrowDownward,
  Remove,
} from '@mui/icons-material';
import { adminAPI } from '../services/api';
import { useAuth } from '../contexts/AuthContext';
import { format } from 'date-fns';

interface DashboardStats {
  overview: {
    total_organizations: number;
    total_users: number;
    total_assessments: number;
    total_expenses: number;
    active_organizations: number;
    avg_score: string;
    recent_growth: {
      organizations: number;
      users: number;
      assessments: number;
    };
    growth_rate_organizations: string;
  };
}

interface Organization {
  id: number;
  name: string;
  sector: string;
  size: string;
  createdAt: string;
  user_count: number;
  response_count: number;
  latest_assessment: {
    score: number;
    level: string;
    questionnaire: string;
    date: string;
  } | null;
  total_expenses: number;
}

interface SectorAnalysis {
  sectors: Array<{
    name: string;
    count: number;
    avg_score: string;
    total_expenses: number;
    avg_expense_per_org: number;
  }>;
  summary: {
    total_sectors: number;
    most_common_sector: string;
    highest_avg_score: number;
    lowest_avg_score: number;
  };
}

const DashboardPage: React.FC = () => {
  const { isSuperAdmin } = useAuth();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [organizations, setOrganizations] = useState<Organization[]>([]);
  const [sectorAnalysis, setSectorAnalysis] = useState<SectorAnalysis | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    if (isSuperAdmin) {
      fetchDashboardData();
    }
  }, [isSuperAdmin]);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      setError(null);

      const [statsResponse, orgsResponse, sectorsResponse] = await Promise.all([
        adminAPI.getDashboardStats(),
        adminAPI.getOrganizations({ page: 1, limit: 5 }),
        adminAPI.getSectorAnalysis(),
      ]);

      setStats(statsResponse.data);
      setOrganizations(orgsResponse.data.organizations || []);
      setSectorAnalysis(sectorsResponse.data);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Өгөгдөл авахад алдаа гарлаа');
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchDashboardData();
    setRefreshing(false);
  };

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'Эхний шат':
        return 'error';
      case 'Хөгжүүлэлтийн шат':
        return 'warning';
      case 'Идэвхтэй шат':
        return 'success';
      case 'Тогтвортой шат':
        return 'info';
      default:
        return 'default';
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('mn-MN', {
      style: 'currency',
      currency: 'MNT',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  if (!isSuperAdmin) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="warning">
          Зөвхөн систем админ энэ хэсэгт нэвтрэх боломжтой
        </Alert>
      </Box>
    );
  }

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '50vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ flexGrow: 1 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" gutterBottom>
          Системийн Dashboard
        </Typography>
        <Button
          variant="outlined"
          startIcon={<Refresh />}
          onClick={handleRefresh}
          disabled={refreshing}
        >
          {refreshing ? 'Шинэчлэж байна...' : 'Шинэчлэх'}
        </Button>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {stats && (
        <>
          {/* Overview Cards */}
          <Grid container spacing={3} sx={{ mb: 4 }}>
            <Grid item xs={12} sm={6} md={3}>
              <Card>
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <Box
                      sx={{
                        backgroundColor: 'primary.light',
                        borderRadius: '50%',
                        p: 1.5,
                        mr: 2,
                      }}
                    >
                      <Business sx={{ color: 'white' }} />
                    </Box>
                    <Box>
                      <Typography variant="h4" component="div">
                        {stats.overview.total_organizations}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Нийт байгууллага
                      </Typography>
                    </Box>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <TrendingUp sx={{ fontSize: 16, mr: 0.5, color: 'success.main' }} />
                    <Typography variant="caption" color="success.main">
                      +{stats.overview.recent_growth.organizations} сүүлийн 30 хоног
                    </Typography>
                  </Box>
                </CardContent>
              </Card>
            </Grid>

            <Grid item xs={12} sm={6} md={3}>
              <Card>
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <Box
                      sx={{
                        backgroundColor: 'success.light',
                        borderRadius: '50%',
                        p: 1.5,
                        mr: 2,
                      }}
                    >
                      <People sx={{ color: 'white' }} />
                    </Box>
                    <Box>
                      <Typography variant="h4" component="div">
                        {stats.overview.total_users}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Нийт хэрэглэгч
                      </Typography>
                    </Box>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <TrendingUp sx={{ fontSize: 16, mr: 0.5, color: 'success.main' }} />
                    <Typography variant="caption" color="success.main">
                      +{stats.overview.recent_growth.users} сүүлийн 30 хоног
                    </Typography>
                  </Box>
                </CardContent>
              </Card>
            </Grid>

            <Grid item xs={12} sm={6} md={3}>
              <Card>
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <Box
                      sx={{
                        backgroundColor: 'warning.light',
                        borderRadius: '50%',
                        p: 1.5,
                        mr: 2,
                      }}
                    >
                      <Assessment sx={{ color: 'white' }} />
                    </Box>
                    <Box>
                      <Typography variant="h4" component="div">
                        {stats.overview.total_assessments}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Нийт үнэлгээ
                      </Typography>
                    </Box>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <TrendingUp sx={{ fontSize: 16, mr: 0.5, color: 'success.main' }} />
                    <Typography variant="caption" color="success.main">
                      +{stats.overview.recent_growth.assessments} сүүлийн 30 хоног
                    </Typography>
                  </Box>
                </CardContent>
              </Card>
            </Grid>

            <Grid item xs={12} sm={6} md={3}>
              <Card>
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <Box
                      sx={{
                        backgroundColor: 'info.light',
                        borderRadius: '50%',
                        p: 1.5,
                        mr: 2,
                      }}
                    >
                      <ShowChart sx={{ color: 'white' }} />
                    </Box>
                    <Box>
                      <Typography variant="h4" component="div">
                        {stats.overview.avg_score}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Дундаж оноо
                      </Typography>
                    </Box>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <TrendingUp sx={{ fontSize: 16, mr: 0.5, color: 'success.main' }} />
                    <Typography variant="caption">
                      Өсөлт: {stats.overview.growth_rate_organizations}%
                    </Typography>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          </Grid>

          <Grid container spacing={3}>
            {/* Recent Organizations */}
            <Grid item xs={12} md={8}>
              <Paper sx={{ p: 3 }}>
                <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center' }}>
                  <Business sx={{ mr: 1 }} />
                  Сүүлийн 5 байгууллага
                </Typography>
                <TableContainer>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>Байгууллага</TableCell>
                        <TableCell>Салбар</TableCell>
                        <TableCell align="center">Хэрэглэгч</TableCell>
                        <TableCell align="center">Үнэлгээ</TableCell>
                        <TableCell align="center">Сүүлийн үнэлгээ</TableCell>
                        <TableCell align="right">Нийт зардал</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {organizations.map((org) => (
                        <TableRow key={org.id} hover>
                          <TableCell>
                            <Typography variant="body2" fontWeight="medium">
                              {org.name}
                            </Typography>
                            <Typography variant="caption" color="text.secondary">
                              {format(new Date(org.createdAt), 'yyyy-MM-dd')}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <Chip
                              label={org.sector || 'Тодорхойгүй'}
                              size="small"
                              variant="outlined"
                            />
                          </TableCell>
                          <TableCell align="center">
                            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                              <People sx={{ fontSize: 16, mr: 0.5, color: 'primary.main' }} />
                              <Typography variant="body2">{org.user_count}</Typography>
                            </Box>
                          </TableCell>
                          <TableCell align="center">
                            <Chip
                              label={org.response_count}
                              size="small"
                              color="primary"
                              variant="outlined"
                            />
                          </TableCell>
                          <TableCell align="center">
                            {org.latest_assessment ? (
                              <Box>
                                <Typography variant="body2" fontWeight="medium">
                                  {org.latest_assessment.score}%
                                </Typography>
                                <Chip
                                  label={org.latest_assessment.level}
                                  size="small"
                                  color={getLevelColor(org.latest_assessment.level) as any}
                                />
                              </Box>
                            ) : (
                              <Typography variant="body2" color="text.secondary">
                                Үгүй
                              </Typography>
                            )}
                          </TableCell>
                          <TableCell align="right">
                            <Typography variant="body2" fontWeight="medium">
                              {formatCurrency(org.total_expenses)}
                            </Typography>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
                <Box sx={{ mt: 2, display: 'flex', justifyContent: 'flex-end' }}>
                  <Button
                    variant="text"
                    size="small"
                    onClick={() => window.location.href = '/organizations'}
                  >
                    Бүгдийг харах →
                  </Button>
                </Box>
              </Paper>

              {/* Sector Analysis */}
              {sectorAnalysis && (
                <Paper sx={{ p: 3, mt: 3 }}>
                  <Typography variant="h6" gutterBottom>
                    Салбарын шинжилгээ
                  </Typography>
                  <TableContainer>
                    <Table size="small">
                      <TableHead>
                        <TableRow>
                          <TableCell>Салбар</TableCell>
                          <TableCell align="center">Байгууллагын тоо</TableCell>
                          <TableCell align="center">Дундаж оноо</TableCell>
                          <TableCell align="right">Нийт зардал</TableCell>
                          <TableCell align="right">Байгууллагад ногдох дундаж</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {sectorAnalysis.sectors.slice(0, 5).map((sector, index) => (
                          <TableRow key={index}>
                            <TableCell>
                              <Typography variant="body2">{sector.name}</Typography>
                            </TableCell>
                            <TableCell align="center">
                              <Chip label={sector.count} size="small" />
                            </TableCell>
                            <TableCell align="center">
                              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                <Typography variant="body2" sx={{ mr: 1 }}>
                                  {sector.avg_score}%
                                </Typography>
                                {parseFloat(sector.avg_score) > 60 ? (
                                  <ArrowUpward sx={{ fontSize: 16, color: 'success.main' }} />
                                ) : parseFloat(sector.avg_score) < 40 ? (
                                  <ArrowDownward sx={{ fontSize: 16, color: 'error.main' }} />
                                ) : (
                                  <Remove sx={{ fontSize: 16, color: 'warning.main' }} />
                                )}
                              </Box>
                            </TableCell>
                            <TableCell align="right">
                              <Typography variant="body2">
                                {formatCurrency(sector.total_expenses)}
                              </Typography>
                            </TableCell>
                            <TableCell align="right">
                              <Typography variant="body2">
                                {formatCurrency(sector.avg_expense_per_org)}
                              </Typography>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                  <Box sx={{ mt: 2 }}>
                    <Typography variant="body2" color="text.secondary">
                      <strong>Хамгийн өндөр дундаж оноо:</strong>{' '}
                      {sectorAnalysis.summary.highest_avg_score.toFixed(1)}% |{' '}
                      <strong>Хамгийн өргөн тархсан салбар:</strong>{' '}
                      {sectorAnalysis.summary.most_common_sector}
                    </Typography>
                  </Box>
                </Paper>
              )}
            </Grid>
            
            {/* Quick Actions & System Info */}
            <Grid item xs={12} md={4}>
              <Paper sx={{ p: 3, mb: 3 }}>
                <Typography variant="h6" gutterBottom>
                  Түргэн үйлдлүүд
                </Typography>
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                  <Button variant="contained" color="primary" fullWidth>
                    Шинэ байгууллага нэмэх
                  </Button>
                  <Button variant="outlined" color="secondary" fullWidth>
                    Асуулгуудыг удирдах
                  </Button>
                  <Button variant="outlined" fullWidth>
                    Тайлан үүсгэх
                  </Button>
                  <Button variant="outlined" fullWidth>
                    Системийн тохиргоо
                  </Button>
                </Box>
              </Paper>

              <Paper sx={{ p: 3 }}>
                <Typography variant="h6" gutterBottom>
                  Системийн мэдээлэл
                </Typography>
                <Box sx={{ mb: 2 }}>
                  <Typography variant="subtitle2" gutterBottom>
                    Өгөгдлийн сан холболт
                  </Typography>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <Box
                      sx={{
                        width: 8,
                        height: 8,
                        borderRadius: '50%',
                        backgroundColor: 'success.main',
                        mr: 1,
                      }}
                    />
                    <Typography variant="body2">Болсон</Typography>
                  </Box>
                </Box>

                <Box sx={{ mb: 2 }}>
                  <Typography variant="subtitle2" gutterBottom>
                    Seed өгөгдөл
                  </Typography>
                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <Typography variant="body2">
                      {stats.overview.total_organizations > 0 ? 'Орсон' : 'Ороогүй'}
                    </Typography>
                    <Chip
                      label={stats.overview.total_organizations > 0 ? 'Бэлэн' : 'Хүлээгдэж байна'}
                      size="small"
                      color={stats.overview.total_organizations > 0 ? 'success' : 'warning'}
                    />
                  </Box>
                </Box>

                <Box sx={{ mb: 2 }}>
                  <Typography variant="subtitle2" gutterBottom>
                    Идэвхтэй байгууллага
                  </Typography>
                  <LinearProgress
                    variant="determinate"
                    value={(stats.overview.active_organizations / stats.overview.total_organizations) * 100}
                    sx={{ mb: 1 }}
                  />
                  <Typography variant="body2" align="right">
                    {stats.overview.active_organizations} / {stats.overview.total_organizations}
                  </Typography>
                </Box>

                <Box>
                  <Typography variant="subtitle2" gutterBottom>
                    Сүүлийн шинэчлэлт
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {format(new Date(), 'yyyy-MM-dd HH:mm')}
                  </Typography>
                </Box>
              </Paper>
            </Grid>
          </Grid>
        </>
      )}
    </Box>
  );
};

export default DashboardPage;