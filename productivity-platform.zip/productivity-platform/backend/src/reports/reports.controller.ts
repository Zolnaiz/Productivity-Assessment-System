import { Controller, Get, UseGuards, Req, Query } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { Roles } from '../shared/decorators/roles.decorator';
import { UserRole } from '../shared/entities/user.entity';
import { RolesGuard } from '../auth/guards/roles.guard';
import { ReportsService } from './reports.service';

@Controller('reports')
@UseGuards(JwtAuthGuard, RolesGuard)
export class ReportsController {
  constructor(private reportsService: ReportsService) {}

  @Get('org/overview')
  @Roles(UserRole.ORG_ADMIN, UserRole.STAFF)
  async getOrganizationOverview(@Req() req) {
    return this.reportsService.getOrganizationOverview(req.user.organizationId);
  }

  @Get('org/detailed')
  @Roles(UserRole.ORG_ADMIN)
  async getOrganizationDetailed(@Req() req, @Query() query: any) {
    const startDate = query.start_date ? new Date(query.start_date) : null;
    const endDate = query.end_date ? new Date(query.end_date) : null;
    
    return this.reportsService.getOrganizationDetailed(
      req.user.organizationId,
      startDate,
      endDate
    );
  }

  @Get('org/expenses/summary')
  @Roles(UserRole.ORG_ADMIN)
  async getExpenseSummary(@Req() req, @Query() query: any) {
    const startDate = query.start_date ? new Date(query.start_date) : null;
    const endDate = query.end_date ? new Date(query.end_date) : null;
    
    return this.reportsService.getExpenseSummary(
      req.user.organizationId,
      startDate,
      endDate
    );
  }
}