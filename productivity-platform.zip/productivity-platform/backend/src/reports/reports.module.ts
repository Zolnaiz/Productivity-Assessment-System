import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ReportsController } from './reports.controller';
import { ReportsService } from './reports.service';
import { Response } from '../shared/entities/response.entity';
import { Expense } from '../shared/entities/expense.entity';
import { Questionnaire } from '../shared/entities/questionnaire.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Response, Expense, Questionnaire])],
  controllers: [ReportsController],
  providers: [ReportsService],
  exports: [ReportsService],
})
export class ReportsModule {}