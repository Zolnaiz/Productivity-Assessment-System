import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Between } from 'typeorm';
import { Response } from '../shared/entities/response.entity';
import { Expense } from '../shared/entities/expense.entity';
import { Questionnaire } from '../shared/entities/questionnaire.entity';
import { ScoringUtils } from '../shared/utils/scoring.utils';

@Injectable()
export class ReportsService {
  constructor(
    @InjectRepository(Response)
    private responseRepository: Repository<Response>,
    @InjectRepository(Expense)
    private expenseRepository: Repository<Expense>,
    @InjectRepository(Questionnaire)
    private questionnaireRepository: Repository<Questionnaire>,
  ) {}

  async getOrganizationOverview(organizationId: number): Promise<any> {
    // Get recent responses (last 10)
    const responses = await this.responseRepository.find({
      where: { organizationId },
      relations: ['questionnaire'],
      order: { takenAt: 'DESC' },
      take: 10,
    });

    // Get recent expenses (last 10)
    const expenses = await this.expenseRepository.find({
      where: { organizationId },
      order: { occurredOn: 'DESC' },
      take: 10,
    });

    // Calculate statistics
    const totalAssessments = await this.responseRepository.count({
      where: { organizationId },
    });

    const totalExpenses = await this.expenseRepository
      .createQueryBuilder('expense')
      .select('SUM(expense.amount)', 'total')
      .where('expense.organization_id = :organizationId', { organizationId })
      .getRawOne();

    // Calculate average score
    let averageScore = 0;
    if (responses.length > 0) {
      const validScores = responses.filter(r => r.percentage !== null && r.percentage !== undefined);
      if (validScores.length > 0) {
        averageScore = validScores.reduce((sum, r) => sum + r.percentage, 0) / validScores.length;
      }
    }

    // Calculate productivity index
    const productivityIndex = ScoringUtils.calculateProductivityIndex(responses, expenses);

    // Get latest assessment
    const latestAssessment = responses.length > 0 ? responses[0] : null;

    return {
      overview: {
        total_assessments: totalAssessments,
        total_expenses: parseFloat(totalExpenses?.total || 0),
        average_score: parseFloat(averageScore.toFixed(2)),
        productivity_index: productivityIndex,
        latest_level: latestAssessment?.level || 'N/A',
        latest_score: latestAssessment?.percentage || 0,
        assessment_trend: responses.length >= 2 
          ? ScoringUtils.calculateTrend(
              responses[0]?.percentage || 0,
              responses[1]?.percentage || 0
            )
          : null,
      },
      recent_assessments: responses.map(r => ({
        id: r.id,
        questionnaire_id: r.questionnaireId,
        questionnaire_title: r.questionnaire?.title,
        percentage: r.percentage,
        level: r.level,
        taken_at: r.takenAt,
      })),
      recent_expenses: expenses.map(e => ({
        id: e.id,
        category: e.category,
        amount: e.amount,
        occurred_on: e.occurredOn,
        note: e.note,
      })),
    };
  }

  async getOrganizationDetailed(organizationId: number, startDate?: Date, endDate?: Date): Promise<any> {
    const where: any = { organizationId };
    
    if (startDate && endDate) {
      where.takenAt = Between(startDate, endDate);
    }

    const responses = await this.responseRepository.find({
      where,
      relations: ['questionnaire'],
      order: { takenAt: 'DESC' },
    });

    // Group by questionnaire
    const byQuestionnaire = {};
    responses.forEach(response => {
      const qId = response.questionnaireId;
      if (!byQuestionnaire[qId]) {
        byQuestionnaire[qId] = {
          questionnaire_id: qId,
          questionnaire_title: response.questionnaire?.title,
          responses: [],
          average_score: 0,
          count: 0,
        };
      }
      byQuestionnaire[qId].responses.push({
        id: response.id,
        percentage: response.percentage,
        level: response.level,
        taken_at: response.takenAt,
      });
      byQuestionnaire[qId].count++;
    });

    // Calculate averages
    Object.values(byQuestionnaire).forEach((q: any) => {
      if (q.responses.length > 0) {
        q.average_score = q.responses.reduce((sum, r) => sum + r.percentage, 0) / q.responses.length;
      }
    });

    // Calculate trends
    const trends = [];
    if (responses.length > 1) {
      // Group by month
      const byMonth = {};
      responses.forEach(r => {
        const month = r.takenAt.toISOString().slice(0, 7); // YYYY-MM
        if (!byMonth[month]) {
          byMonth[month] = { scores: [], count: 0 };
        }
        byMonth[month].scores.push(r.percentage);
        byMonth[month].count++;
      });

      Object.keys(byMonth).sort().forEach(month => {
        const data = byMonth[month];
        if (data.scores.length > 0) {
          const avg = data.scores.reduce((sum, s) => sum + s, 0) / data.scores.length;
          trends.push({
            month,
            average_score: parseFloat(avg.toFixed(2)),
            count: data.count,
          });
        }
      });
    }

    return {
      summary: {
        total_responses: responses.length,
        time_period: {
          start: startDate || (responses.length > 0 ? responses[responses.length - 1].takenAt : null),
          end: endDate || (responses.length > 0 ? responses[0].takenAt : null),
        },
        questionnaires_count: Object.keys(byQuestionnaire).length,
      },
      by_questionnaire: Object.values(byQuestionnaire),
      trends: trends,
    };
  }

  async getExpenseSummary(organizationId: number, startDate?: Date, endDate?: Date): Promise<any> {
    const where: any = { organizationId };
    
    if (startDate && endDate) {
      where.occurredOn = Between(startDate, endDate);
    }

    const expenses = await this.expenseRepository.find({
      where,
      order: { occurredOn: 'DESC' },
    });

    // Group by category
    const byCategory = {};
    let total = 0;
    
    expenses.forEach(expense => {
      const category = expense.category || 'Бусад';
      if (!byCategory[category]) {
        byCategory[category] = {
          category,
          total: 0,
          count: 0,
          expenses: [],
        };
      }
      byCategory[category].total += parseFloat(expense.amount.toString());
      byCategory[category].count++;
      byCategory[category].expenses.push({
        id: expense.id,
        amount: expense.amount,
        occurred_on: expense.occurredOn,
        note: expense.note,
      });
      total += parseFloat(expense.amount.toString());
    });

    // Calculate percentages and sort
    const categories = Object.values(byCategory)
      .map((c: any) => ({
        ...c,
        percentage: total > 0 ? (c.total / total) * 100 : 0,
        average: c.count > 0 ? c.total / c.count : 0,
      }))
      .sort((a: any, b: any) => b.total - a.total);

    // Group by month
    const byMonth = {};
    expenses.forEach(expense => {
      const month = expense.occurredOn.toISOString().slice(0, 7); // YYYY-MM
      if (!byMonth[month]) {
        byMonth[month] = { total: 0, count: 0 };
      }
      byMonth[month].total += parseFloat(expense.amount.toString());
      byMonth[month].count++;
    });

    const monthlyTrends = Object.keys(byMonth)
      .sort()
      .map(month => ({
        month,
        total: byMonth[month].total,
        count: byMonth[month].count,
        average: byMonth[month].count > 0 ? byMonth[month].total / byMonth[month].count : 0,
      }));

    return {
      summary: {
        total_expenses: total,
        expense_count: expenses.length,
        category_count: categories.length,
        time_period: {
          start: startDate || (expenses.length > 0 ? expenses[expenses.length - 1].occurredOn : null),
          end: endDate || (expenses.length > 0 ? expenses[0].occurredOn : null),
        },
        average_per_expense: expenses.length > 0 ? total / expenses.length : 0,
      },
      by_category: categories,
      monthly_trends: monthlyTrends,
      recommendations: this.generateExpenseRecommendations(categories, total),
    };
  }

  private generateExpenseRecommendations(categories: any[], total: number): string[] {
    const recommendations = [];
    
    if (total === 0) {
      return ['Зардлын мэдээлэл байхгүй байна'];
    }

    // Check for high spending categories (> 40% of total)
    const highSpending = categories.filter(c => c.percentage > 40);
    if (highSpending.length > 0) {
      highSpending.forEach(c => {
        recommendations.push(`${c.category} зардал нийт зардлын ${c.percentage.toFixed(1)}% эзэлж байна. Энэ зардлыг бууруулах арга хэмжээ авч үзэх`);
      });
    }

    // Check for many small expenses
    const manySmallExpenses = categories.filter(c => c.count > 10 && c.average < total * 0.01);
    if (manySmallExpenses.length > 0) {
      recommendations.push('Олон тооны жижиг зардалтай. Нэгтгэх боломжтой эсэхийг шалгах');
    }

    // General recommendations
    if (recommendations.length === 0) {
      recommendations.push(
        'Зардлын бүртгэл тогтмол хөтлөх',
        'Зардлын төсөв төлөвлөх',
        'Зардлын үр ашгийг үнэлэх'
      );
    }

    return recommendations.slice(0, 5);
  }
}