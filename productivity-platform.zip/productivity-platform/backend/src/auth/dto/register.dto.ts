import { IsEmail, IsString, MinLength, IsOptional, IsPhoneNumber, Matches } from 'class-validator';

export class RegisterDto {
  @IsEmail({}, { message: 'Хүчингүй имэйл хаяг' })
  email: string;

  @IsString({ message: 'Нууц үг шаардлагатай' })
  @MinLength(6, { message: 'Нууц үг хамгийн багадаа 6 тэмдэгт байх ёстой' })
  @Matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/, {
    message: 'Нууц үг нь том жижиг үсэг, тоо агуулсан байх ёстой'
  })
  password: string;

  @IsString({ message: 'Бүтэн нэр шаардлагатай' })
  @MinLength(2, { message: 'Бүтэн нэр хамгийн багадаа 2 тэмдэгт байх ёстой' })
  fullName: string;

  @IsString({ message: 'Байгууллагын нэр шаардлагатай' })
  organizationName: string;

  @IsOptional()
  @IsString({ message: 'Регистрийн дугаар буруу форматтай' })
  regNumber?: string;

  @IsOptional()
  @IsString({ message: 'Салбар буруу форматтай' })
  sector?: string;

  @IsOptional()
  @IsString({ message: 'Хэмжээ буруу форматтай' })
  size?: string;

  @IsOptional()
  @IsPhoneNumber('MN', { message: 'Хүчингүй утасны дугаар' })
  phoneNumber?: string;
}