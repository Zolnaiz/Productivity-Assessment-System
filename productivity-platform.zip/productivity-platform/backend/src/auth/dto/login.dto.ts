import { IsEmail, IsString, MinLength } from 'class-validator';

export class LoginDto {
  @IsEmail({}, { message: 'Хүчингүй имэйл хаяг' })
  email: string;

  @IsString({ message: 'Нууц үг шаардлагатай' })
  @MinLength(6, { message: 'Нууц үг хамгийн багадаа 6 тэмдэгт байх ёстой' })
  password: string;
}