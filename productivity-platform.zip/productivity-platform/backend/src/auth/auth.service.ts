import { Injectable, UnauthorizedException, ConflictException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from '../shared/entities/user.entity';
import { Organization } from '../shared/entities/organization.entity';
import { LoginDto } from './dto/login.dto';
import { RegisterDto } from './dto/register.dto';

@Injectable()
export class AuthService {
  constructor(
    @InjectRepository(User)
    private userRepository: Repository<User>,
    @InjectRepository(Organization)
    private organizationRepository: Repository<Organization>,
    private jwtService: JwtService,
  ) {}

  async validateUser(email: string, password: string): Promise<User> {
    const user = await this.userRepository.findOne({
      where: { email },
      relations: ['organization'],
    });

    if (user && await user.validatePassword(password)) {
      user.lastLoginAt = new Date();
      await this.userRepository.save(user);
      return user;
    }
    return null;
  }

  async login(loginDto: LoginDto) {
    const user = await this.validateUser(loginDto.email, loginDto.password);
    
    if (!user) {
      throw new UnauthorizedException('Invalid credentials');
    }

    if (!user.isActive) {
      throw new UnauthorizedException('Account is inactive');
    }

    const payload = {
      sub: user.id,
      email: user.email,
      role: user.role,
      organizationId: user.organization.id,
    };

    return {
      access_token: this.jwtService.sign(payload),
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        fullName: user.fullName,
        role: user.role,
        organization: user.organization,
      },
    };
  }

  async register(registerDto: RegisterDto) {
    // Check if email exists
    const existingUser = await this.userRepository.findOne({
      where: { email: registerDto.email },
    });

    if (existingUser) {
      throw new ConflictException('Email already exists');
    }

    // Check if organization exists
    let organization = await this.organizationRepository.findOne({
      where: { code: registerDto.organizationCode },
    });

    if (!organization) {
      // Create new organization for super admin
      organization = this.organizationRepository.create({
        name: registerDto.organizationName || 'New Organization',
        code: registerDto.organizationCode,
        email: registerDto.email,
      });
      await this.organizationRepository.save(organization);
    }

    // Check organization user limit
    const userCount = await this.userRepository.count({
      where: { organization: { id: organization.id } },
    });

    if (userCount >= organization.maxUsers) {
      throw new ConflictException('Organization user limit reached');
    }

    // Create user
    const user = this.userRepository.create({
      email: registerDto.email,
      username: registerDto.username,
      password: registerDto.password,
      fullName: registerDto.fullName,
      role: registerDto.role || 'user',
      organization,
    });

    await this.userRepository.save(user);

    // Generate token
    const payload = {
      sub: user.id,
      email: user.email,
      role: user.role,
      organizationId: organization.id,
    };

    return {
      access_token: this.jwtService.sign(payload),
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        fullName: user.fullName,
        role: user.role,
        organization,
      },
    };
  }

  async refreshToken(userId: string) {
    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: ['organization'],
    });

    if (!user) {
      throw new UnauthorizedException('User not found');
    }

    const payload = {
      sub: user.id,
      email: user.email,
      role: user.role,
      organizationId: user.organization.id,
    };

    return {
      access_token: this.jwtService.sign(payload),
    };
  }
}