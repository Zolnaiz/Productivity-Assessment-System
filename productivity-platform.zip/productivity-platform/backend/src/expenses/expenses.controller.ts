import { Controller, Get, Post, Body, UseGuards, Req, Query } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { Roles } from '../shared/decorators/roles.decorator';
import { UserRole } from '../shared/entities/user.entity';
import { RolesGuard } from '../auth/guards/roles.guard';
import { ExpensesService } from './expenses.service';

@Controller('expenses')
@UseGuards(JwtAuthGuard, RolesGuard)
export class ExpensesController {
  constructor(private expensesService: ExpensesService) {}

  @Post()
  @Roles(UserRole.ORG_ADMIN)
  async createExpense(@Req() req, @Body() body: any) {
    return this.expensesService.createExpense(req.user.organizationId, body);
  }

  @Get('org')
  @Roles(UserRole.ORG_ADMIN, UserRole.STAFF)
  async getOrganizationExpenses(@Req() req, @Query() query: any) {
    const limit = query.limit ? parseInt(query.limit) : 100;
    const startDate = query.start_date ? new Date(query.start_date) : null;
    const endDate = query.end_date ? new Date(query.end_date) : null;
    
    return this.expensesService.getOrganizationExpenses(
      req.user.organizationId,
      limit,
      startDate,
      endDate
    );
  }
}