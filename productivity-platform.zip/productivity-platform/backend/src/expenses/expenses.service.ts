import { Injectable, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Between } from 'typeorm';
import { Expense } from '../shared/entities/expense.entity';

@Injectable()
export class ExpensesService {
  constructor(
    @InjectRepository(Expense)
    private expenseRepository: Repository<Expense>,
  ) {}

  async createExpense(organizationId: number, data: any): Promise<Expense> {
    // Validate required fields
    if (!data.category) {
      throw new BadRequestException('Категори шаардлагатай');
    }

    if (!data.amount || isNaN(parseFloat(data.amount))) {
      throw new BadRequestException('Хүчинтэй дүн шаардлагатай');
    }

    if (!data.occurred_on) {
      throw new BadRequestException('Гарсан огноо шаардлагатай');
    }

    const expense = this.expenseRepository.create({
      organizationId,
      category: data.category,
      amount: parseFloat(data.amount),
      occurredOn: new Date(data.occurred_on),
      note: data.note || null,
      paymentMethod: data.payment_method || null,
      invoiceNumber: data.invoice_number || null,
      isRecurring: data.is_recurring || false,
    });

    return this.expenseRepository.save(expense);
  }

  async getOrganizationExpenses(
    organizationId: number, 
    limit: number = 100,
    startDate?: Date,
    endDate?: Date
  ): Promise<Expense[]> {
    const where: any = { organizationId };
    
    if (startDate && endDate) {
      where.occurredOn = Between(startDate, endDate);
    } else if (startDate) {
      where.occurredOn = Between(startDate, new Date());
    }

    return this.expenseRepository.find({
      where,
      order: { occurredOn: 'DESC' },
      take: limit,
    });
  }

  async getExpenseSummary(organizationId: number, startDate?: Date, endDate?: Date): Promise<any> {
    const query = this.expenseRepository
      .createQueryBuilder('expense')
      .select('expense.category', 'category')
      .addSelect('SUM(expense.amount)', 'total')
      .addSelect('COUNT(expense.id)', 'count')
      .where('expense.organization_id = :organizationId', { organizationId });

    if (startDate && endDate) {
      query.andWhere('expense.occurred_on BETWEEN :startDate AND :endDate', {
        startDate,
        endDate,
      });
    }

    query.groupBy('expense.category').orderBy('total', 'DESC');

    const results = await query.getRawMany();

    const total = results.reduce((sum, item) => sum + parseFloat(item.total), 0);

    return {
      categories: results.map(item => ({
        category: item.category,
        total: parseFloat(item.total),
        count: parseInt(item.count),
        percentage: total > 0 ? (parseFloat(item.total) / total) * 100 : 0,
      })),
      summary: {
        total_expenses: total,
        expense_count: results.reduce((sum, item) => sum + parseInt(item.count), 0),
        category_count: results.length,
        average_per_category: results.length > 0 ? total / results.length : 0,
      },
    };
  }
}