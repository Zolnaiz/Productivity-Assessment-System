import { Controller, Get, Param, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { QuestionnairesService } from './questionnaires.service';

@Controller('questionnaires')
@UseGuards(JwtAuthGuard)
export class QuestionnairesController {
  constructor(private questionnairesService: QuestionnairesService) {}

  @Get()
  async getAll() {
    return this.questionnairesService.getAllActive();
  }

  @Get(':id')
  async getById(@Param('id') id: number) {
    return this.questionnairesService.findById(id);
  }
}