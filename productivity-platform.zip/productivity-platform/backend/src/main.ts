import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { ValidationPipe } from '@nestjs/common';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  
  app.useGlobalPipes(new ValidationPipe({
    whitelist: true,
    transform: true,
    forbidNonWhitelisted: true,
  }));
  
  // Enable CORS for development
  app.enableCors({
    origin: [
      'http://localhost:3000',    // Admin web
      'http://localhost:5173',    // Vite dev server
      'http://localhost:8080',    // Flutter web
      'http://localhost:4000',    // Backend itself (for health check)
    ],
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  });
  
  await app.listen(4000);
  console.log(`🚀 Backend API is running on: ${await app.getUrl()}`);
  console.log(`📊 Health check: ${await app.getUrl()}/health`);
  console.log(`🔐 Authentication: ${await app.getUrl()}/auth`);
}
bootstrap();