import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Organization } from '../shared/entities/organization.entity';

@Injectable()
export class OrganizationsService {
  constructor(
    @InjectRepository(Organization)
    private organizationRepository: Repository<Organization>,
  ) {}

  async findOrganizationById(id: number): Promise<Organization> {
    const organization = await this.organizationRepository.findOne({
      where: { id },
    });
    
    if (!organization) {
      throw new NotFoundException('Байгууллага олдсонгүй');
    }
    
    return organization;
  }
}