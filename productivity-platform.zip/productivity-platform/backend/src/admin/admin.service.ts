import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Between } from 'typeorm';
import { Organization } from '../shared/entities/organization.entity';
import { User } from '../shared/entities/user.entity';
import { Response } from '../shared/entities/response.entity';
import { Expense } from '../shared/entities/expense.entity';
import { Questionnaire } from '../shared/entities/questionnaire.entity';

@Injectable()
export class AdminService {
  constructor(
    @InjectRepository(Organization)
    private organizationRepository: Repository<Organization>,
    @InjectRepository(User)
    private userRepository: Repository<User>,
    @InjectRepository(Response)
    private responseRepository: Repository<Response>,
    @InjectRepository(Expense)
    private expenseRepository: Repository<Expense>,
    @InjectRepository(Questionnaire)
    private questionnaireRepository: Repository<Questionnaire>,
  ) {}

  async getDashboardStats() {
    const [
      totalOrganizations,
      totalUsers,
      totalResponses,
      totalExpenses,
      activeOrganizations,
    ] = await Promise.all([
      this.organizationRepository.count(),
      this.userRepository.count(),
      this.responseRepository.count(),
      this.expenseRepository.count(),
      this.organizationRepository
        .createQueryBuilder('org')
        .innerJoin('org.responses', 'response')
        .where('response.createdAt > :date', { 
          date: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) 
        })
        .getCount(),
    ]);

    // Calculate average scores
    const avgScores = await this.responseRepository
      .createQueryBuilder('response')
      .select('AVG(response.percentage)', 'avgPercentage')
      .addSelect('AVG(response.totalScore)', 'avgScore')
      .getRawOne();

    // Recent growth (last 30 days)
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const recentOrganizations = await this.organizationRepository
      .createQueryBuilder('org')
      .where('org.createdAt > :date', { date: thirtyDaysAgo })
      .getCount();

    const recentUsers = await this.userRepository
      .createQueryBuilder('user')
      .where('user.createdAt > :date', { date: thirtyDaysAgo })
      .getCount();

    const recentResponses = await this.responseRepository
      .createQueryBuilder('response')
      .where('response.createdAt > :date', { date: thirtyDaysAgo })
      .getCount();

    return {
      overview: {
        total_organizations: totalOrganizations,
        total_users: totalUsers,
        total_assessments: totalResponses,
        total_expenses: totalExpenses,
        active_organizations: activeOrganizations,
        avg_score: parseFloat(avgScores?.avgPercentage || 0).toFixed(1),
        recent_growth: {
          organizations: recentOrganizations,
          users: recentUsers,
          assessments: recentResponses,
        },
        growth_rate_organizations: totalOrganizations > 0 ? 
          ((recentOrganizations / totalOrganizations) * 100).toFixed(1) : '0',
      },
    };
  }

  async getOrganizations(params: any) {
    const { page = 1, limit = 20, sector, size, search } = params;
    const skip = (page - 1) * limit;

    const query = this.organizationRepository
      .createQueryBuilder('org')
      .leftJoinAndSelect('org.users', 'users')
      .leftJoinAndSelect('org.responses', 'responses')
      .loadRelationCountAndMap('org.user_count', 'org.users')
      .loadRelationCountAndMap('org.response_count', 'org.responses')
      .orderBy('org.createdAt', 'DESC')
      .skip(skip)
      .take(limit);

    if (sector) {
      query.andWhere('org.sector = :sector', { sector });
    }

    if (size) {
      query.andWhere('org.size = :size', { size });
    }

    if (search) {
      query.andWhere('(org.name LIKE :search OR org.regNumber LIKE :search)', {
        search: `%${search}%`,
      });
    }

    const [organizations, total] = await query.getManyAndCount();

    // Calculate statistics for each organization
    const organizationsWithStats = await Promise.all(
      organizations.map(async (org) => {
        const latestResponse = await this.responseRepository.findOne({
          where: { organizationId: org.id },
          order: { takenAt: 'DESC' },
          relations: ['questionnaire'],
        });

        const totalExpenses = await this.expenseRepository
          .createQueryBuilder('expense')
          .select('SUM(expense.amount)', 'total')
          .where('expense.organizationId = :orgId', { orgId: org.id })
          .getRawOne();

        const userCount = await this.userRepository.count({
          where: { organizationId: org.id },
        });

        const responseCount = await this.responseRepository.count({
          where: { organizationId: org.id },
        });

        return {
          id: org.id,
          name: org.name,
          regNumber: org.regNumber,
          sector: org.sector,
          size: org.size,
          contactEmail: org.contactEmail,
          contactPhone: org.contactPhone,
          createdAt: org.createdAt,
          user_count: userCount,
          response_count: responseCount,
          latest_assessment: latestResponse
            ? {
                score: latestResponse.percentage,
                level: latestResponse.level,
                questionnaire: latestResponse.questionnaire?.title,
                date: latestResponse.takenAt,
              }
            : null,
          total_expenses: parseFloat(totalExpenses?.total || 0),
        };
      })
    );

    return {
      organizations: organizationsWithStats,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit),
      },
    };
  }

  async getOrganizationDetails(id: number) {
    const organization = await this.organizationRepository.findOne({
      where: { id },
      relations: ['users', 'responses', 'expenses'],
    });

    if (!organization) {
      throw new Error('Organization not found');
    }

    // Get statistics
    const users = await this.userRepository.find({
      where: { organizationId: id },
      select: ['id', 'email', 'fullName', 'role', 'position', 'lastLoginAt'],
    });

    const responses = await this.responseRepository.find({
      where: { organizationId: id },
      relations: ['questionnaire'],
      order: { takenAt: 'DESC' },
      take: 50,
    });

    const expenses = await this.expenseRepository.find({
      where: { organizationId: id },
      order: { occurredOn: 'DESC' },
      take: 50,
    });

    // Calculate scores by questionnaire
    const scoresByQuestionnaire = {};
    responses.forEach(r => {
      const qId = r.questionnaireId;
      if (!scoresByQuestionnaire[qId]) {
        scoresByQuestionnaire[qId] = {
          questionnaire_id: qId,
          questionnaire_title: r.questionnaire?.title,
          scores: [],
          average: 0,
        };
      }
      scoresByQuestionnaire[qId].scores.push(r.percentage);
    });

    Object.values(scoresByQuestionnaire).forEach((q: any) => {
      if (q.scores.length > 0) {
        q.average = q.scores.reduce((sum, s) => sum + s, 0) / q.scores.length;
      }
    });

    // Expense summary
    const expenseSummary = {};
    expenses.forEach(e => {
      const category = e.category || 'Бусад';
      if (!expenseSummary[category]) {
        expenseSummary[category] = { total: 0, count: 0 };
      }
      expenseSummary[category].total += parseFloat(e.amount.toString());
      expenseSummary[category].count++;
    });

    return {
      organization: {
        id: organization.id,
        name: organization.name,
        regNumber: organization.regNumber,
        sector: organization.sector,
        size: organization.size,
        contactEmail: organization.contactEmail,
        contactPhone: organization.contactPhone,
        address: organization.address,
        createdAt: organization.createdAt,
      },
      statistics: {
        user_count: users.length,
        response_count: responses.length,
        expense_count: expenses.length,
        active_users: users.filter(u => u.lastLoginAt && 
          new Date(u.lastLoginAt).getTime() > Date.now() - 30 * 24 * 60 * 60 * 1000
        ).length,
      },
      users: users,
      assessments: {
        by_questionnaire: Object.values(scoresByQuestionnaire),
        recent: responses.slice(0, 10).map(r => ({
          id: r.id,
          questionnaire: r.questionnaire?.title,
          percentage: r.percentage,
          level: r.level,
          taken_at: r.takenAt,
        })),
      },
      expenses: {
        summary: Object.entries(expenseSummary).map(([category, data]: [string, any]) => ({
          category,
          total: data.total,
          count: data.count,
          average: data.count > 0 ? data.total / data.count : 0,
        })),
        recent: expenses.slice(0, 10).map(e => ({
          id: e.id,
          category: e.category,
          amount: e.amount,
          occurred_on: e.occurredOn,
          note: e.note,
        })),
      },
    };
  }

  async getSectorAnalysis() {
    const sectors = await this.organizationRepository
      .createQueryBuilder('org')
      .select('org.sector, COUNT(org.id) as count')
      .where('org.sector IS NOT NULL')
      .groupBy('org.sector')
      .getRawMany();

    // Calculate average scores by sector
    const sectorScores = await this.responseRepository
      .createQueryBuilder('response')
      .innerJoin('response.organization', 'org')
      .select('org.sector, AVG(response.percentage) as avg_score')
      .where('org.sector IS NOT NULL')
      .groupBy('org.sector')
      .getRawMany();

    const sectorData = sectors.map(s => ({
      name: s.sector,
      count: parseInt(s.count),
      avg_score: parseFloat(
        sectorScores.find(ss => ss.sector === s.sector)?.avg_score || 0
      ).toFixed(1),
    }));

    // Calculate expense by sector
    const sectorExpenses = await this.expenseRepository
      .createQueryBuilder('expense')
      .innerJoin('expense.organization', 'org')
      .select('org.sector, SUM(expense.amount) as total_expenses')
      .where('org.sector IS NOT NULL')
      .groupBy('org.sector')
      .getRawMany();

    sectorData.forEach(sector => {
      const expenseData = sectorExpenses.find(se => se.sector === sector.name);
      sector.total_expenses = parseFloat(expenseData?.total_expenses || 0);
      sector.avg_expense_per_org = sector.count > 0 ? 
        sector.total_expenses / sector.count : 0;
    });

    return {
      sectors: sectorData.sort((a, b) => b.count - a.count),
      summary: {
        total_sectors: sectorData.length,
        most_common_sector: sectorData[0]?.name || 'N/A',
        highest_avg_score: Math.max(...sectorData.map(s => parseFloat(s.avg_score))),
        lowest_avg_score: Math.min(...sectorData.map(s => parseFloat(s.avg_score))),
      },
    };
  }

  async getSystemStatus() {
    const dbStatus = await this.organizationRepository.query('SELECT 1 as status');
    
    const memoryUsage = process.memoryUsage();
    const uptime = process.uptime();

    return {
      status: 'healthy',
      timestamp: new Date().toISOString(),
      uptime: {
        seconds: uptime,
        formatted: this.formatUptime(uptime),
      },
      memory: {
        rss: Math.round(memoryUsage.rss / 1024 / 1024) + 'MB',
        heapTotal: Math.round(memoryUsage.heapTotal / 1024 / 1024) + 'MB',
        heapUsed: Math.round(memoryUsage.heapUsed / 1024 / 1024) + 'MB',
        external: Math.round(memoryUsage.external / 1024 / 1024) + 'MB',
      },
      database: dbStatus ? 'connected' : 'disconnected',
      environment: process.env.NODE_ENV || 'development',
      node_version: process.version,
      platform: process.platform,
    };
  }

  async getActivityLogs(params: any) {
    const { page = 1, limit = 50, type, start_date, end_date } = params;
    const skip = (page - 1) * limit;

    // In a real application, you would have an activity log table
    // For now, we'll return sample data
    const sampleLogs = [
      {
        id: 1,
        type: 'user_login',
        user_id: 1,
        user_email: 'demo@company.mn',
        organization_id: 1,
        description: 'Хэрэглэгч нэвтэрлээ',
        timestamp: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
        ip_address: '192.168.1.100',
      },
      {
        id: 2,
        type: 'assessment_submitted',
        user_id: 2,
        user_email: 'staff@company.mn',
        organization_id: 1,
        description: 'Үнэлгээ илгээгдлээ',
        timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
        metadata: { questionnaire_id: 1, score: 75.5 },
      },
      {
        id: 3,
        type: 'organization_created',
        user_id: 3,
        user_email: 'superadmin@productivity.mn',
        organization_id: null,
        description: 'Шинэ байгууллага бүртгэгдлээ',
        timestamp: new Date(Date.now() - 1000 * 60 * 60).toISOString(),
        metadata: { organization_name: 'Demo Organization' },
      },
    ];

    // Filter by type if provided
    let filteredLogs = sampleLogs;
    if (type) {
      filteredLogs = sampleLogs.filter(log => log.type === type);
    }

    // Filter by date range if provided
    if (start_date && end_date) {
      const start = new Date(start_date);
      const end = new Date(end_date);
      filteredLogs = filteredLogs.filter(log => {
        const logTime = new Date(log.timestamp);
        return logTime >= start && logTime <= end;
      });
    }

    // Paginate
    const paginatedLogs = filteredLogs.slice(skip, skip + limit);

    return {
      logs: paginatedLogs,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total: filteredLogs.length,
        pages: Math.ceil(filteredLogs.length / limit),
      },
      summary: {
        total_logs: filteredLogs.length,
        by_type: this.countByType(filteredLogs),
        recent_activity: filteredLogs.slice(0, 5),
      },
    };
  }

  private formatUptime(seconds: number): string {
    const days = Math.floor(seconds / (24 * 60 * 60));
    const hours = Math.floor((seconds % (24 * 60 * 60)) / (60 * 60));
    const minutes = Math.floor((seconds % (60 * 60)) / 60);
    const secs = Math.floor(seconds % 60);

    const parts = [];
    if (days > 0) parts.push(`${days} хоног`);
    if (hours > 0) parts.push(`${hours} цаг`);
    if (minutes > 0) parts.push(`${minutes} минут`);
    if (secs > 0) parts.push(`${secs} секунд`);

    return parts.join(' ');
  }

  private countByType(logs: any[]): any {
    const counts = {};
    logs.forEach(log => {
      counts[log.type] = (counts[log.type] || 0) + 1;
    });
    return counts;
  }
}