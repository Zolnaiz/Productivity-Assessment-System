import { Controller, Get, Post, Body, UseGuards, Req, Query, Param } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { Roles } from '../shared/decorators/roles.decorator';
import { UserRole } from '../shared/entities/user.entity';
import { RolesGuard } from '../auth/guards/roles.guard';
import { AdminService } from './admin.service';

@Controller('admin')
@UseGuards(JwtAuthGuard, RolesGuard)
export class AdminController {
  constructor(private adminService: AdminService) {}

  @Get('dashboard/stats')
  @Roles(UserRole.SUPERADMIN)
  async getDashboardStats() {
    return this.adminService.getDashboardStats();
  }

  @Get('organizations')
  @Roles(UserRole.SUPERADMIN)
  async getOrganizations(@Query() params: any) {
    return this.adminService.getOrganizations(params);
  }

  @Get('organizations/:id')
  @Roles(UserRole.SUPERADMIN)
  async getOrganization(@Param('id') id: number) {
    return this.adminService.getOrganizationDetails(id);
  }

  @Get('analytics/sectors')
  @Roles(UserRole.SUPERADMIN)
  async getSectorAnalysis() {
    return this.adminService.getSectorAnalysis();
  }

  @Get('system/status')
  @Roles(UserRole.SUPERADMIN)
  async getSystemStatus() {
    return this.adminService.getSystemStatus();
  }

  @Get('activity/logs')
  @Roles(UserRole.SUPERADMIN)
  async getActivityLogs(@Query() params: any) {
    return this.adminService.getActivityLogs(params);
  }
}