import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AdminController } from './admin.controller';
import { AdminService } from './admin.service';
import { Organization } from '../shared/entities/organization.entity';
import { User } from '../shared/entities/user.entity';
import { Response } from '../shared/entities/response.entity';
import { Expense } from '../shared/entities/expense.entity';
import { Questionnaire } from '../shared/entities/questionnaire.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Organization,
      User,
      Response,
      Expense,
      Questionnaire,
    ]),
  ],
  controllers: [AdminController],
  providers: [AdminService],
  exports: [AdminService],
})
export class AdminModule {}