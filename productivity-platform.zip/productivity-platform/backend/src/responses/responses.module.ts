import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ResponsesController } from './responses.controller';
import { ResponsesService } from './responses.service';
import { Response } from '../shared/entities/response.entity';
import { Questionnaire } from '../shared/entities/questionnaire.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Response, Questionnaire])],
  controllers: [ResponsesController],
  providers: [ResponsesService],
  exports: [ResponsesService],
})
export class ResponsesModule {}