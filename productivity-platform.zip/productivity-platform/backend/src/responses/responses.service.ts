import { Injectable, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Response } from '../shared/entities/response.entity';
import { Questionnaire } from '../shared/entities/questionnaire.entity';
import { ScoringUtils } from '../shared/utils/scoring.utils';

@Injectable()
export class ResponsesService {
  constructor(
    @InjectRepository(Response)
    private responseRepository: Repository<Response>,
    @InjectRepository(Questionnaire)
    private questionnaireRepository: Repository<Questionnaire>,
  ) {}

  async createResponse(user: any, data: any): Promise<Response> {
    // Validate required fields
    if (!data.questionnaire_id) {
      throw new BadRequestException('Асуулгын ID шаардлагатай');
    }

    if (!data.answers || typeof data.answers !== 'object') {
      throw new BadRequestException('Хариултууд шаардлагатай');
    }

    // Get questionnaire
    const questionnaire = await this.questionnaireRepository.findOne({
      where: { id: data.questionnaire_id },
    });

    if (!questionnaire) {
      throw new BadRequestException('Асуулга олдсонгүй');
    }

    // Calculate scores using advanced scoring system
    const scores = ScoringUtils.calculateScore(questionnaire, data.answers);

    // Create response
    const response = this.responseRepository.create({
      organizationId: user.organizationId,
      userId: user.id,
      questionnaireId: data.questionnaire_id,
      answers: data.answers,
      totalScore: scores.total_score,
      percentage: scores.percentage,
      level: scores.level,
      sectionScores: scores.section_scores,
      summary: scores.summary,
      takenAt: new Date(),
      completionTime: data.completion_time || null,
      notes: data.notes || null,
    });

    return this.responseRepository.save(response);
  }

  async getOrganizationResponses(organizationId: number, limit: number = 50): Promise<Response[]> {
    return this.responseRepository.find({
      where: { organizationId },
      relations: ['questionnaire'],
      order: { takenAt: 'DESC' },
      take: limit,
    });
  }

  async getResponseById(id: number, organizationId: number): Promise<Response> {
    const response = await this.responseRepository.findOne({
      where: { id, organizationId },
      relations: ['questionnaire', 'user'],
    });

    if (!response) {
      throw new BadRequestException('Үнэлгээ олдсонгүй');
    }

    return response;
  }
}