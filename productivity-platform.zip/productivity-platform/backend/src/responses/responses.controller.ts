import { Controller, Get, Post, Body, UseGuards, Req, Query } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { Roles } from '../shared/decorators/roles.decorator';
import { UserRole } from '../shared/entities/user.entity';
import { RolesGuard } from '../auth/guards/roles.guard';
import { ResponsesService } from './responses.service';

@Controller('responses')
@UseGuards(JwtAuthGuard, RolesGuard)
export class ResponsesController {
  constructor(private responsesService: ResponsesService) {}

  @Post()
  @Roles(UserRole.ORG_ADMIN, UserRole.STAFF)
  async createResponse(@Req() req, @Body() body: any) {
    return this.responsesService.createResponse(req.user, body);
  }

  @Get('org')
  @Roles(UserRole.ORG_ADMIN, UserRole.STAFF, UserRole.SUPERADMIN)
  async getOrganizationResponses(@Req() req, @Query() query: any) {
    const limit = query.limit ? parseInt(query.limit) : 50;
    return this.responsesService.getOrganizationResponses(req.user.organizationId, limit);
  }
}