import { Entity, Column, OneToMany, OneToOne } from 'typeorm';
import { BaseEntity } from './base.entity';
import { User } from './user.entity';
import { Questionnaire } from './questionnaire.entity';
import { Expense } from './expense.entity';

@Entity('organizations')
export class Organization extends BaseEntity {
  @Column({ unique: true })
  name: string;

  @Column({ nullable: true })
  description: string;

  @Column({ unique: true })
  code: string;

  @Column({ default: true })
  isActive: boolean;

  @Column({ nullable: true })
  address: string;

  @Column({ nullable: true })
  phoneNumber: string;

  @Column({ nullable: true })
  email: string;

  @Column({ nullable: true })
  logoUrl: string;

  @Column({ type: 'jsonb', nullable: true })
  settings: {
    defaultLanguage: string;
    timezone: string;
    currency: string;
    theme: string;
  };

  @OneToMany(() => User, (user) => user.organization)
  users: User[];

  @OneToMany(() => Questionnaire, (questionnaire) => questionnaire.organization)
  questionnaires: Questionnaire[];

  @OneToMany(() => Expense, (expense) => expense.organization)
  expenses: Expense[];

  @Column({ type: 'timestamp', nullable: true })
  subscriptionEndsAt: Date;

  @Column({ default: 0 })
  maxUsers: number;

  @Column({ default: 0 })
  maxQuestionnaires: number;
}