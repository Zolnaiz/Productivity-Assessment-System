import { Entity, Column, ManyToOne, JoinColumn, Index } from 'typeorm';
import { BaseEntity } from './base.entity';
import { Organization } from './organization.entity';
import { User } from './user.entity';
import { Questionnaire } from './questionnaire.entity';

@Entity('responses')
@Index(['organizationId', 'questionnaireId', 'takenAt'])
@Index(['userId', 'takenAt'])
export class Response extends BaseEntity {
  @Column({ name: 'organization_id' })
  organizationId: number;

  @Column({ name: 'user_id' })
  userId: number;

  @Column({ name: 'questionnaire_id' })
  questionnaireId: number;

  @Column({ type: 'json' })
  answers: any;

  @Column({ name: 'total_score', type: 'float', nullable: true })
  totalScore: number;

  @Column({ type: 'float', nullable: true })
  percentage: number;

  @Column({ length: 50, nullable: true })
  level: string;

  @Column({ name: 'section_scores', type: 'json', nullable: true })
  sectionScores: any;

  @Column({ type: 'json', nullable: true })
  summary: any;

  @Column({ name: 'taken_at', type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
  takenAt: Date;

  @Column({ name: 'completion_time', type: 'int', nullable: true })
  completionTime: number;

  @Column({ type: 'text', nullable: true })
  notes: string;

  @ManyToOne(() => Organization, organization => organization.responses, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'organization_id' })
  organization: Organization;

  @ManyToOne(() => User, user => user.responses, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'user_id' })
  user: User;

  @ManyToOne(() => Questionnaire, questionnaire => questionnaire.responses, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'questionnaire_id' })
  questionnaire: Questionnaire;
}