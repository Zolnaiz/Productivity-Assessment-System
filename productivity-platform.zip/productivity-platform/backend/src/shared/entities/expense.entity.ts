import { Entity, Column, ManyToOne, JoinColumn, Index } from 'typeorm';
import { BaseEntity } from './base.entity';
import { Organization } from './organization.entity';

@Entity('expenses')
@Index(['organizationId', 'occurredOn'])
@Index(['category', 'occurredOn'])
export class Expense extends BaseEntity {
  @Column({ name: 'organization_id' })
  organizationId: number;

  @Column({ length: 100 })
  category: string;

  @Column({ type: 'decimal', precision: 15, scale: 2 })
  amount: number;

  @Column({ name: 'occurred_on', type: 'date' })
  occurredOn: Date;

  @Column({ type: 'text', nullable: true })
  note: string;

  @Column({ name: 'payment_method', length: 50, nullable: true })
  paymentMethod: string;

  @Column({ name: 'invoice_number', length: 50, nullable: true })
  invoiceNumber: string;

  @Column({ name: 'is_recurring', default: false })
  isRecurring: boolean;

  @ManyToOne(() => Organization, organization => organization.expenses, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'organization_id' })
  organization: Organization;
}