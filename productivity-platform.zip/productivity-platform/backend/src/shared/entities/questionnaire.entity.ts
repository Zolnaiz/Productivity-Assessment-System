import { Entity, Column, OneToMany } from 'typeorm';
import { BaseEntity } from './base.entity';
import { Response } from './response.entity';

@Entity('questionnaires')
export class Questionnaire extends BaseEntity {
  @Column({ length: 100, unique: true })
  slug: string;

  @Column({ length: 200 })
  title: string;

  @Column({ type: 'text', nullable: true })
  description: string;

  @Column({ type: 'json', nullable: true })
  definition: any;

  @Column({ name: 'is_active', default: true })
  isActive: boolean;

  @Column({ name: 'category', length: 50, nullable: true })
  category: string;

  @Column({ name: 'estimated_time', type: 'int', nullable: true })
  estimatedTime: number;

  @Column({ name: 'question_count', type: 'int', default: 0 })
  questionCount: number;

  @OneToMany(() => Response, response => response.questionnaire)
  responses: Response[];
}