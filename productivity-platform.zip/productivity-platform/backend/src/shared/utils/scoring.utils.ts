import { Injectable } from '@nestjs/common';

@Injectable()
export class ScoringUtils {
  static calculateScore(questionnaire: any, answers: any) {
    const definition = questionnaire.definition || {};
    const sections = definition.sections || [];
    const scoringConfig = definition.scoring || {};
    
    if (!sections || sections.length === 0) {
      return this.calculateDefaultScore(answers);
    }

    let totalWeightedScore = 0;
    let totalPossibleScore = 0;
    const sectionScores = {};
    const sectionDetails = [];

    // Calculate for each section
    for (const section of sections) {
      const sectionId = section.id || `section_${sections.indexOf(section)}`;
      const sectionWeight = section.weight || 1;
      const sectionQuestions = section.questions || [];

      let sectionScore = 0;
      let sectionMaxScore = 0;
      const questionDetails = [];

      // Calculate each question in section
      for (const question of sectionQuestions) {
        const questionId = question.id || `q_${sectionQuestions.indexOf(question)}`;
        const answerValue = answers[questionId];
        
        if (answerValue !== undefined && answerValue !== null) {
          // Calculate question score (1-5 scale to 0-100%)
          const questionMaxValue = question.max || 5; // Default scale is 1-5
          const questionMinValue = question.min || 1;
          const questionRange = questionMaxValue - questionMinValue;
          
          const normalizedScore = (answerValue - questionMinValue) / questionRange;
          const questionScore = normalizedScore * 100;
          
          // Apply question weight
          const questionWeight = question.weight || 1;
          const weightedQuestionScore = questionScore * questionWeight;
          
          sectionScore += weightedQuestionScore;
          sectionMaxScore += 100 * questionWeight;
          
          questionDetails.push({
            id: questionId,
            question: question.question || '',
            answer: answerValue,
            score: questionScore,
            weightedScore: weightedQuestionScore,
            weight: questionWeight,
            max: questionMaxValue,
            min: questionMinValue,
          });
        }
      }

      // Calculate section percentage
      const sectionPercentage = sectionMaxScore > 0 
        ? (sectionScore / sectionMaxScore) * 100 
        : 0;
      
      // Apply section weight
      const weightedSectionScore = sectionPercentage * sectionWeight;
      const weightedSectionMax = 100 * sectionWeight;
      
      sectionScores[sectionId] = {
        title: section.title || `Section ${sectionId}`,
        score: parseFloat(sectionPercentage.toFixed(2)),
        weightedScore: parseFloat(weightedSectionScore.toFixed(2)),
        questionCount: sectionQuestions.length,
        answeredQuestions: questionDetails.length,
        questions: questionDetails,
      };

      sectionDetails.push({
        id: sectionId,
        title: section.title || `Section ${sectionId}`,
        weight: sectionWeight,
        score: parseFloat(sectionPercentage.toFixed(2)),
        weightedScore: parseFloat(weightedSectionScore.toFixed(2)),
      });

      totalWeightedScore += weightedSectionScore;
      totalPossibleScore += weightedSectionMax;
    }

    // Calculate overall percentage
    const overallPercentage = totalPossibleScore > 0 
      ? (totalWeightedScore / totalPossibleScore) * 100 
      : 0;

    // Determine level
    const levels = scoringConfig.levels || this.getDefaultLevels();
    const level = this.determineLevel(levels, overallPercentage);

    // Generate suggestions
    const suggestions = this.generateSuggestions(scoringConfig.suggestions, level, sectionScores);

    // Identify strengths and improvements
    const strengths = this.identifyStrengths(sectionScores);
    const improvements = this.identifyImprovements(sectionScores);

    // Generate summary
    const summary = {
      total_score: parseFloat(totalWeightedScore.toFixed(2)),
      percentage: parseFloat(overallPercentage.toFixed(2)),
      level: level,
      section_count: sections.length,
      answered_questions: Object.keys(answers).length,
      total_questions: sections.reduce((sum, s) => sum + (s.questions?.length || 0), 0),
      strengths: strengths,
      areas_for_improvement: improvements,
      recommendations: suggestions,
      calculated_at: new Date().toISOString(),
      scoring_version: '1.1',
      metadata: {
        questionnaire_id: questionnaire.id,
        questionnaire_title: questionnaire.title,
      }
    };

    return {
      total_score: parseFloat(totalWeightedScore.toFixed(2)),
      percentage: parseFloat(overallPercentage.toFixed(2)),
      level: level,
      section_scores: sectionScores,
      section_details: sectionDetails,
      summary: summary,
    };
  }

  private static calculateDefaultScore(answers: any) {
    const answeredCount = Object.keys(answers).length;
    if (answeredCount === 0) {
      return {
        total_score: 0,
        percentage: 0,
        level: 'No Data',
        section_scores: {},
        section_details: [],
        summary: {
          total_score: 0,
          percentage: 0,
          level: 'No Data',
          answered_questions: 0,
          total_questions: 0,
          strengths: [],
          areas_for_improvement: [],
          recommendations: ['Та асуулгаа бөглөнө үү'],
          calculated_at: new Date().toISOString(),
        }
      };
    }

    // Simple average calculation
    const values = Object.values(answers).filter(v => typeof v === 'number') as number[];
    const average = values.reduce((sum, val) => sum + val, 0) / values.length;
    const percentage = (average / 5) * 100;
    
    const levels = this.getDefaultLevels();
    const level = this.determineLevel(levels, percentage);

    return {
      total_score: parseFloat(average.toFixed(2)),
      percentage: parseFloat(percentage.toFixed(2)),
      level: level,
      section_scores: {
        default: {
          title: 'Default Section',
          score: percentage,
          weightedScore: percentage,
          questionCount: values.length,
          answeredQuestions: values.length,
        }
      },
      section_details: [{
        id: 'default',
        title: 'Default Section',
        weight: 1,
        score: percentage,
        weightedScore: percentage,
      }],
      summary: {
        total_score: parseFloat(average.toFixed(2)),
        percentage: parseFloat(percentage.toFixed(2)),
        level: level,
        answered_questions: values.length,
        total_questions: values.length,
        strengths: ['Анхны үнэлгээ амжилттай бөглөгдлөө'],
        areas_for_improvement: ['Илүү нарийвчилсан үнэлгээнд оролцоорой'],
        recommendations: ['Дараагийн үнэлгээгээ цаг тухайд нь хийх'],
        calculated_at: new Date().toISOString(),
      }
    };
  }

  private static getDefaultLevels() {
    return [
      { min: 0, max: 40, level: 'Эхний шат', color: '#ff4444', description: 'Суурь шатанд байна' },
      { min: 41, max: 60, level: 'Хөгжүүлэлтийн шат', color: '#ffbb33', description: 'Хөгжиж байна' },
      { min: 61, max: 80, level: 'Идэвхтэй шат', color: '#00C851', description: 'Идэвхтэй ажиллаж байна' },
      { min: 81, max: 100, level: 'Тогтвортой шат', color: '#33b5e5', description: 'Тогтвортой хөгжиж байна' }
    ];
  }

  static determineLevel(levels: any[], percentage: number): string {
    if (!levels || levels.length === 0) {
      return this.getDefaultLevels().find(l => 
        percentage >= l.min && percentage <= l.max
      )?.level || 'Тодорхойгүй';
    }

    // Sort levels by min value to ensure proper checking
    const sortedLevels = [...levels].sort((a, b) => a.min - b.min);
    
    for (const level of sortedLevels) {
      if (percentage >= level.min && percentage <= level.max) {
        return level.level;
      }
    }

    return 'Тодорхойгүй';
  }

  static generateSuggestions(suggestionsConfig: any, level: string, sectionScores: any): string[] {
    const suggestions = [];

    // Add level-based suggestions
    if (suggestionsConfig && suggestionsConfig[level]) {
      const levelSuggestions = Array.isArray(suggestionsConfig[level]) 
        ? suggestionsConfig[level] 
        : [];
      suggestions.push(...levelSuggestions);
    }

    // Add section-based suggestions for low scores
    for (const [sectionId, section] of Object.entries(sectionScores)) {
      const sectionData = section as any;
      if (sectionData.score < 50) {
        suggestions.push(`${sectionData.title} хэсгийн үнэлгээг дээшлүүлэх шаардлагатай`);
      }
    }

    // Add general suggestions if none
    if (suggestions.length === 0) {
      suggestions.push(
        'Тасралтгүй сайжруулалтыг үргэлжлүүлэх',
        'Шинэ технологи, аргуудыг судлах',
        'Ажилтнуудын ур чадварыг хөгжүүлэх',
        'Мэдлэг, туршлагаа хуваалцах',
        'Шийдвэр гаргалтын процессийг сайжруулах'
      );
    }

    return suggestions.slice(0, 5); // Limit to 5 suggestions
  }

  static identifyStrengths(sectionScores: any): string[] {
    const strengths = [];
    
    for (const [sectionId, section] of Object.entries(sectionScores)) {
      const sectionData = section as any;
      if (sectionData.score >= 75) {
        strengths.push(sectionData.title);
      }
    }

    if (strengths.length === 0) {
      strengths.push('Ялгаатай давуу тал байхгүй байна');
    }

    return strengths;
  }

  static identifyImprovements(sectionScores: any): string[] {
    const improvements = [];
    
    for (const [sectionId, section] of Object.entries(sectionScores)) {
      const sectionData = section as any;
      if (sectionData.score < 50) {
        improvements.push(sectionData.title);
      }
    }

    if (improvements.length === 0) {
      improvements.push('Бүх хэсэг дунд дээш түвшинд байна');
    }

    return improvements;
  }

  static calculateProductivityIndex(responses: any[], expenses: any[]): number {
    if (responses.length === 0) return 50;

    // Calculate average score from responses
    const validResponses = responses.filter(r => r.percentage !== null && r.percentage !== undefined);
    const avgScore = validResponses.length > 0 
      ? validResponses.reduce((sum, r) => sum + r.percentage, 0) / validResponses.length 
      : 50;

    // Calculate expense efficiency
    let expenseEfficiency = 50;
    if (expenses.length > 0) {
      const validExpenses = expenses.filter(e => e.amount !== null && e.amount !== undefined);
      if (validExpenses.length > 0) {
        const totalExpenses = validExpenses.reduce((sum, e) => {
          const amount = typeof e.amount === 'string' ? parseFloat(e.amount) : e.amount;
          return sum + (amount || 0);
        }, 0);
        const avgExpense = totalExpenses / validExpenses.length;
        
        // More sophisticated efficiency calculation
        expenseEfficiency = Math.max(0, Math.min(100, 100 - (Math.log10(avgExpense + 1) * 10)));
      }
    }

    // Weighted average
    const productivityIndex = (avgScore * 0.7) + (expenseEfficiency * 0.3);

    return Math.round(productivityIndex * 100) / 100;
  }

  static calculateTrend(currentScore: number, previousScore: number): {
    direction: 'up' | 'down' | 'stable';
    percentage: number;
    message: string;
  } {
    if (!previousScore || previousScore === 0) {
      return {
        direction: 'stable',
        percentage: 0,
        message: 'Өмнөх үнэлгээ байхгүй'
      };
    }

    const change = ((currentScore - previousScore) / previousScore) * 100;
    const absChange = Math.abs(change);

    if (change > 5) {
      return {
        direction: 'up',
        percentage: parseFloat(change.toFixed(1)),
        message: `Өмнөхөөс ${absChange.toFixed(1)}% өссөн`
      };
    } else if (change < -5) {
      return {
        direction: 'down',
        percentage: parseFloat(change.toFixed(1)),
        message: `Өмнөхөөс ${absChange.toFixed(1)}% буурсан`
      };
    } else {
      return {
        direction: 'stable',
        percentage: parseFloat(change.toFixed(1)),
        message: 'Өмнөхтэй төстэй'
      };
    }
  }
}