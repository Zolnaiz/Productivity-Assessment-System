import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcrypt';
import { Organization } from '../entities/organization.entity';
import { User } from '../entities/user.entity';
import { Questionnaire } from '../entities/questionnaire.entity';
import { Expense } from '../entities/expense.entity';

@Injectable()
export class DetailedSeedService {
  private readonly logger = new Logger(DetailedSeedService.name);

  constructor(
    @InjectRepository(Organization)
    private organizationRepository: Repository<Organization>,
    @InjectRepository(User)
    private userRepository: Repository<User>,
    @InjectRepository(Questionnaire)
    private questionnaireRepository: Repository<Questionnaire>,
    @InjectRepository(Expense)
    private expenseRepository: Repository<Expense>,
  ) {}

  async seed() {
    this.logger.log('Starting database seed...');

    // Clear existing data
    await this.clearDatabase();

    // Seed organizations
    const organizations = await this.seedOrganizations();
    
    // Seed users
    const users = await this.seedUsers(organizations);
    
    // Seed questionnaires
    await this.seedQuestionnaires(organizations, users);
    
    // Seed expenses
    await this.seedExpenses(organizations, users);

    this.logger.log('Database seed completed successfully');
  }

  private async clearDatabase() {
    await this.expenseRepository.delete({});
    await this.questionnaireRepository.delete({});
    await this.userRepository.delete({});
    await this.organizationRepository.delete({});
  }

  private async seedOrganizations(): Promise<Organization[]> {
    const organizations = [
      {
        name: 'Tech Corp',
        code: 'TECH001',
        description: 'Technology company',
        email: 'info@techcorp.com',
        phoneNumber: '+1234567890',
        maxUsers: 50,
        maxQuestionnaires: 100,
        settings: {
          defaultLanguage: 'en',
          timezone: 'UTC',
          currency: 'USD',
          theme: 'light',
        },
      },
      {
        name: 'Health Plus',
        code: 'HEALTH002',
        description: 'Healthcare organization',
        email: 'contact@healthplus.org',
        phoneNumber: '+0987654321',
        maxUsers: 30,
        maxQuestionnaires: 50,
        settings: {
          defaultLanguage: 'en',
          timezone: 'EST',
          currency: 'USD',
          theme: 'blue',
        },
      },
    ];

    const savedOrgs = [];
    for (const orgData of organizations) {
      const org = this.organizationRepository.create(orgData);
      savedOrgs.push(await this.organizationRepository.save(org));
    }

    this.logger.log(`Created ${savedOrgs.length} organizations`);
    return savedOrgs;
  }

  private async seedUsers(organizations: Organization[]): Promise<User[]> {
    const users = [
      {
        email: 'superadmin@example.com',
        username: 'superadmin',
        password: await bcrypt.hash('Admin123!', 10),
        fullName: 'Super Admin',
        role: 'super_admin' as any,
        organization: organizations[0],
        isActive: true,
      },
      {
        email: 'admin@techcorp.com',
        username: 'techadmin',
        password: await bcrypt.hash('Tech123!', 10),
        fullName: 'Tech Corp Admin',
        role: 'organization_admin' as any,
        organization: organizations[0],
        isActive: true,
      },
      {
        email: 'user1@techcorp.com',
        username: 'techuser1',
        password: await bcrypt.hash('User123!', 10),
        fullName: 'Tech User One',
        role: 'user' as any,
        organization: organizations[0],
        isActive: true,
      },
      {
        email: 'admin@healthplus.org',
        username: 'healthadmin',
        password: await bcrypt.hash('Health123!', 10),
        fullName: 'Health Plus Admin',
        role: 'organization_admin' as any,
        organization: organizations[1],
        isActive: true,
      },
    ];

    const savedUsers = [];
    for (const userData of users) {
      const user = this.userRepository.create(userData);
      savedUsers.push(await this.userRepository.save(user));
    }

    this.logger.log(`Created ${savedUsers.length} users`);
    return savedUsers;
  }

  private async seedQuestionnaires(organizations: Organization[], users: User[]) {
    const questionnaires = [
      {
        title: 'Employee Satisfaction Survey',
        description: 'Quarterly employee satisfaction survey',
        organization: organizations[0],
        createdBy: users[1],
        questions: [
          {
            text: 'How satisfied are you with your work environment?',
            type: 'scale',
            options: ['1 - Very Unsatisfied', '2', '3', '4', '5 - Very Satisfied'],
          },
          {
            text: 'What can we improve?',
            type: 'text',
          },
        ],
        isActive: true,
      },
      {
        title: 'Patient Feedback Form',
        description: 'Patient experience feedback',
        organization: organizations[1],
        createdBy: users[3],
        questions: [
          {
            text: 'Rate the quality of care received',
            type: 'scale',
            options: ['Poor', 'Fair', 'Good', 'Very Good', 'Excellent'],
          },
        ],
        isActive: true,
      },
    ];

    for (const qData of questionnaires) {
      const questionnaire = this.questionnaireRepository.create(qData);
      await this.questionnaireRepository.save(questionnaire);
    }

    this.logger.log('Created sample questionnaires');
  }

  private async seedExpenses(organizations: Organization[], users: User[]) {
    const expenses = [
      {
        amount: 1500.75,
        description: 'Office supplies purchase',
        category: 'office_supplies',
        date: new Date('2024-01-15'),
        organization: organizations[0],
        user: users[2],
        status: 'approved',
      },
      {
        amount: 5000.00,
        description: 'Software license renewal',
        category: 'software',
        date: new Date('2024-01-20'),
        organization: organizations[0],
        user: users[1],
        status: 'pending',
      },
      {
        amount: 1200.50,
        description: 'Medical equipment maintenance',
        category: 'equipment',
        date: new Date('2024-01-10'),
        organization: organizations[1],
        user: users[3],
        status: 'approved',
      },
    ];

    for (const expenseData of expenses) {
      const expense = this.expenseRepository.create(expenseData);
      await this.expenseRepository.save(expense);
    }

    this.logger.log('Created sample expenses');
  }
}