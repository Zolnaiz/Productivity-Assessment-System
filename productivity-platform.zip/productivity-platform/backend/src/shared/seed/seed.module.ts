import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DetailedSeedService } from './detailed-seed.service';
import { Questionnaire } from '../entities/questionnaire.entity';
import { Organization } from '../entities/organization.entity';
import { User } from '../entities/user.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([Questionnaire, Organization, User]),
  ],
  providers: [DetailedSeedService],
  exports: [DetailedSeedService],
})
export class SeedModule {}