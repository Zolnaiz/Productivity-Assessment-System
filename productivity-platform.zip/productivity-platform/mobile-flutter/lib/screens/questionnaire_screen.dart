import 'package:flutter/material.dart';
import '../services/api_service.dart';

class QuestionnaireScreen extends StatefulWidget {
  final int questionnaireId;
  final String title;

  const QuestionnaireScreen({
    super.key,
    required this.questionnaireId,
    required this.title,
  });

  @override
  _QuestionnaireScreenState createState() => _QuestionnaireScreenState();
}

class _QuestionnaireScreenState extends State<QuestionnaireScreen> {
  final ApiService _apiService = ApiService();
  Map<String, dynamic>? _questionnaire;
  Map<String, dynamic> _answers = {};
  bool _isLoading = true;
  bool _isSubmitting = false;
  int _currentSectionIndex = 0;
  final PageController _pageController = PageController();

  @override
  void initState() {
    super.initState();
    _loadQuestionnaire();
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  Future<void> _loadQuestionnaire() async {
    try {
      final data = await _apiService.getQuestionnaire(widget.questionnaireId);
      setState(() {
        _questionnaire = data;
        _isLoading = false;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Асуулга авахад алдаа гарлаа: $e'),
          backgroundColor: Colors.red,
        ),
      );
      Navigator.pop(context);
    }
  }

  Widget _buildQuestion(Map<String, dynamic> question, int questionIndex) {
    final questionId = question['id'] ?? 'q$questionIndex';
    final currentValue = _answers[questionId];
    
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 24,
                  height: 24,
                  decoration: BoxDecoration(
                    color: Colors.blue.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Center(
                    child: Text(
                      '${questionIndex + 1}',
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: Colors.blue,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    question['question'] ?? 'Асуулт',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            
            // Scale input (1-5)
            if (question['type'] == 'scale' || question['type'] == null)
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Үнэлэх (1-5):',
                    style: TextStyle(fontSize: 14, color: Colors.grey),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: List.generate(5, (index) {
                      final value = index + 1;
                      final isSelected = currentValue == value;
                      
                      String getLabel(int val) {
                        switch (val) {
                          case 1: return 'Маш муу';
                          case 2: return 'Муу';
                          case 3: return 'Дунд зэрэг';
                          case 4: return 'Сайн';
                          case 5: return 'Маш сайн';
                          default: return '$val';
                        }
                      }
                      
                      return GestureDetector(
                        onTap: () {
                          setState(() {
                            _answers[questionId] = value;
                          });
                        },
                        child: Column(
                          children: [
                            Container(
                              width: 40,
                              height: 40,
                              decoration: BoxDecoration(
                                color: isSelected 
                                    ? Colors.blue 
                                    : Colors.grey[100],
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                  color: isSelected 
                                      ? Colors.blue 
                                      : Colors.grey[300],
                                ),
                              ),
                              child: Center(
                                child: Text(
                                  '$value',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: isSelected 
                                        ? Colors.white 
                                        : Colors.grey[700],
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              getLabel(value),
                              style: TextStyle(
                                fontSize: 10,
                                color: isSelected 
                                    ? Colors.blue 
                                    : Colors.grey[600],
                              ),
                            ),
                          ],
                        ),
                      );
                    }),
                  ),
                ],
              ),
            
            // Text input for notes
            const SizedBox(height: 16),
            TextField(
              onChanged: (value) {
                setState(() {
                  _answers['${questionId}_notes'] = value;
                });
              },
              decoration: const InputDecoration(
                labelText: 'Нэмэлт тайлбар (заавал биш)',
                border: OutlineInputBorder(),
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 8,
                ),
              ),
              maxLines: 3,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSection(Map<String, dynamic> section, int sectionIndex) {
    final questions = List<Map<String, dynamic>>.from(section['questions'] ?? []);
    final sectionTitle = section['title'] ?? 'Хэсэг ${sectionIndex + 1}';
    final sectionDescription = section['description'];

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Card(
            color: Colors.blue.withOpacity(0.05),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    sectionTitle,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.blue,
                    ),
                  ),
                  if (sectionDescription != null) ...[
                    const SizedBox(height: 8),
                    Text(
                      sectionDescription,
                      style: const TextStyle(color: Colors.grey),
                    ),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          ...questions.asMap().entries.map((entry) {
            final index = entry.key;
            final question = entry.value;
            return _buildQuestion(question, index);
          }).toList(),
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  int getAnsweredQuestionsCount() {
    return _answers.keys.where((key) => 
      !key.endsWith('_notes') && _answers[key] != null
    ).length;
  }

  Future<void> _submitQuestionnaire() async {
    // Filter out notes from answers
    final submissionAnswers = Map<String, dynamic>.from(_answers)
      ..removeWhere((key, value) => key.endsWith('_notes'));

    if (submissionAnswers.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Хамгийн багадаа нэг асуултад хариулна уу'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    setState(() {
      _isSubmitting = true;
    });

    try {
      await _apiService.submitResponse({
        'questionnaire_id': widget.questionnaireId,
        'answers': submissionAnswers,
        'notes': _answers.values.where((v) => v is String && v.isNotEmpty).join('\n'),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Амжилттай илгээгдлээ!'),
          backgroundColor: Colors.green,
        ),
      );
      
      Navigator.pop(context, true); // Return success
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Илгээхэд алдаа гарлаа: $e'),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      setState(() {
        _isSubmitting = false;
      });
    }
  }

  void _nextSection() {
    if (_currentSectionIndex < (_questionnaire?['definition']?['sections']?.length ?? 1) - 1) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
      setState(() {
        _currentSectionIndex++;
      });
    }
  }

  void _previousSection() {
    if (_currentSectionIndex > 0) {
      _pageController.previousPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
      setState(() {
        _currentSectionIndex--;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        actions: [
          if (_isSubmitting)
            const Padding(
              padding: EdgeInsets.only(right: 16),
              child: Center(
                child: SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
              ),
            ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _questionnaire == null
              ? const Center(child: Text('Асуулга олдсонгүй'))
              : Column(
                  children: [
                    // Progress indicator
                    LinearProgressIndicator(
                      value: getAnsweredQuestionsCount() / 
                          (_questionnaire!['question_count'] ?? 1),
                      backgroundColor: Colors.grey[200],
                      valueColor: const AlwaysStoppedAnimation<Color>(Colors.blue),
                    ),
                    
                    // Section navigation
                    Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Хэсэг ${_currentSectionIndex + 1}/${_questionnaire!['definition']?['sections']?.length ?? 1}',
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          Text(
                            'Хариулсан: ${getAnsweredQuestionsCount()}/${_questionnaire!['question_count'] ?? 0}',
                            style: const TextStyle(color: Colors.grey),
                          ),
                        ],
                      ),
                    ),
                    
                    // Questionnaire content
                    Expanded(
                      child: PageView.builder(
                        controller: _pageController,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: _questionnaire!['definition']?['sections']?.length ?? 1,
                        itemBuilder: (context, index) {
                          final section = _questionnaire!['definition']?['sections']?[index] ?? {};
                          return _buildSection(section, index);
                        },
                      ),
                    ),
                    
                    // Navigation buttons
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border(top: BorderSide(color: Colors.grey[200]!)),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          ElevatedButton.icon(
                            onPressed: _currentSectionIndex > 0 
                                ? _previousSection 
                                : null,
                            icon: const Icon(Icons.arrow_back),
                            label: const Text('Өмнөх'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.grey[200],
                              foregroundColor: Colors.grey[700],
                            ),
                          ),
                          
                          if (_currentSectionIndex < 
                              (_questionnaire!['definition']?['sections']?.length ?? 1) - 1)
                            ElevatedButton.icon(
                              onPressed: _nextSection,
                              icon: const Text('Дараах'),
                              label: const Icon(Icons.arrow_forward),
                            )
                          else
                            ElevatedButton.icon(
                              onPressed: _isSubmitting ? null : _submitQuestionnaire,
                              icon: const Icon(Icons.check),
                              label: const Text('Илгээх'),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.green,
                                foregroundColor: Colors.white,
                              ),
                            ),
                        ],
                      ),
                    ),
                  ],
                ),
      bottomNavigationBar: _isLoading || _questionnaire == null
          ? null
          : BottomAppBar(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Text(
                  _questionnaire!['description'] ?? '',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.grey, fontSize: 12),
                ),
              ),
            ),
    );
  }
}