import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../providers/auth_provider.dart';
import '../services/api_service.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final ApiService _apiService = ApiService();
  Map<String, dynamic>? _overviewData;
  List<dynamic> _recentAssessments = [];
  bool _isLoading = true;
  bool _isRefreshing = false;

  @override
  void initState() {
    super.initState();
    _loadDashboardData();
  }

  Future<void> _loadDashboardData() async {
    try {
      setState(() {
        _isLoading = true;
      });

      final [overviewData, assessmentsData] = await Future.wait([
        _apiService.getOverview(),
        _apiService.getMyResponses(limit: 5),
      ]);

      setState(() {
        _overviewData = overviewData;
        _recentAssessments = assessmentsData;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Өгөгдөл авахад алдаа гарлаа: $e'),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _refreshData() async {
    setState(() {
      _isRefreshing = true;
    });

    await _loadDashboardData();

    setState(() {
      _isRefreshing = false;
    });
  }

  Widget _buildKpiCard(String title, dynamic value, IconData icon, Color color) {
    String displayValue;
    
    if (value is num) {
      displayValue = value is double ? value.toStringAsFixed(1) : value.toString();
    } else {
      displayValue = value?.toString() ?? 'N/A';
    }
    
    // Add percentage sign for score values
    if (title.contains('Score') || title.contains('Productivity')) {
      displayValue = '$displayValue%';
    }

    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(height: 12),
            Text(
              displayValue,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              title,
              style: TextStyle(
                color: Colors.grey[600],
                fontSize: 12,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAssessmentItem(Map<String, dynamic> assessment) {
    final percentage = (assessment['percentage'] as num?)?.toDouble() ?? 0;
    final level = assessment['level'] ?? 'N/A';
    final title = assessment['questionnaire_title'] ?? 'Асуулга';
    final date = assessment['taken_at'] != null 
        ? DateFormat('yyyy-MM-dd').format(DateTime.parse(assessment['taken_at']))
        : 'N/A';

    Color getLevelColor(String level) {
      switch (level) {
        case 'Эхний шат':
          return Colors.red;
        case 'Хөгжүүлэлтийн шат':
          return Colors.orange;
        case 'Идэвхтэй шат':
          return Colors.green;
        case 'Тогтвортой шат':
          return Colors.blue;
        default:
          return Colors.grey;
      }
    }

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: getLevelColor(level).withOpacity(0.1),
          child: Icon(
            Icons.assessment,
            color: getLevelColor(level),
          ),
        ),
        title: Text(title),
        subtitle: Text(date),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              '${percentage.toStringAsFixed(1)}%',
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
            Text(
              level,
              style: TextStyle(
                fontSize: 12,
                color: getLevelColor(level),
              ),
            ),
          ],
        ),
        onTap: () {
          // Navigate to assessment details
        },
      ),
    );
  }

  Widget _buildOrganizationInfo() {
    final authProvider = Provider.of<AuthProvider>(context);
    final organization = authProvider.currentOrganization;
    final user = authProvider.currentUser;

    if (organization == null) {
      return const Card(
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: Text('Байгууллагын мэдээлэл олдсонгүй'),
        ),
      );
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.business, color: Colors.blue),
                const SizedBox(width: 8),
                Text(
                  organization['name'] ?? 'Байгууллага',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            if (organization['sector'] != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text('Салбар: ${organization['sector']}'),
              ),
            if (organization['size'] != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text('Хэмжээ: ${organization['size']}'),
              ),
            if (user?['position'] != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text('Албан тушаал: ${user!['position']}'),
              ),
            const SizedBox(height: 8),
            const Divider(),
            const SizedBox(height: 8),
            const Text(
              'Хялбар үйлдлүүд:',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                ActionChip(
                  avatar: const Icon(Icons.add, size: 16),
                  label: const Text('Шинэ үнэлгээ'),
                  onPressed: () {
                    Navigator.pushNamed(context, '/questionnaires');
                  },
                ),
                ActionChip(
                  avatar: const Icon(Icons.show_chart, size: 16),
                  label: const Text('Тайлан үзэх'),
                  onPressed: () {
                    Navigator.pushNamed(context, '/reports');
                  },
                ),
                ActionChip(
                  avatar: const Icon(Icons.attach_money, size: 16),
                  label: const Text('Зардал нэмэх'),
                  onPressed: () {
                    Navigator.pushNamed(context, '/expenses/add');
                  },
                ),
                ActionChip(
                  avatar: const Icon(Icons.history, size: 16),
                  label: const Text('Түүх'),
                  onPressed: () {
                    Navigator.pushNamed(context, '/history');
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _isLoading ? null : _refreshData,
            tooltip: 'Шинэчлэх',
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await authProvider.logout();
            },
            tooltip: 'Гарах',
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _refreshData,
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Welcome message
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Сайн байна уу, ${authProvider.currentUser?['fullName'] ?? 'Хэрэглэгч'}! 👋',
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 8),
                            const Text(
                              'Өнөөдрийн бүтээмжээ хэмжиж, сайжруулаарай',
                              style: TextStyle(color: Colors.grey),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Organization info
                    _buildOrganizationInfo(),
                    const SizedBox(height: 16),

                    // KPI Cards
                    const Text(
                      'Байгууллагын тойм',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 12),
                    GridView.count(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      crossAxisCount: 2,
                      childAspectRatio: 1.1,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                      children: [
                        _buildKpiCard(
                          'Нийт үнэлгээ',
                          _overviewData?['overview']['total_assessments'] ?? 0,
                          Icons.assessment,
                          Colors.blue,
                        ),
                        _buildKpiCard(
                          'Дундаж оноо',
                          (_overviewData?['overview']['average_score'] ?? 0).toDouble(),
                          Icons.score,
                          Colors.green,
                        ),
                        _buildKpiCard(
                          'Бүтээмжийн индекс',
                          (_overviewData?['overview']['productivity_index'] ?? 0).toDouble(),
                          Icons.trending_up,
                          Colors.purple,
                        ),
                        _buildKpiCard(
                          'Сүүлийн түвшин',
                          _overviewData?['overview']['latest_level'] ?? 'N/A',
                          Icons.stacked_line_chart,
                          Colors.orange,
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),

                    // Recent Assessments
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Сүүлийн үнэлгээнүүд',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        TextButton(
                          onPressed: () {
                            Navigator.pushNamed(context, '/assessments');
                          },
                          child: const Text('Бүгдийг харах'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    if (_recentAssessments.isEmpty)
                      const Card(
                        child: Padding(
                          padding: EdgeInsets.all(16.0),
                          child: Text('Үнэлгээ байхгүй байна'),
                        ),
                      )
                    else
                      Column(
                        children: _recentAssessments
                            .map((assessment) => _buildAssessmentItem(assessment))
                            .toList(),
                      ),
                    const SizedBox(height: 16),

                    // Quick Stats
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Түргэн статистик',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 12),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                Column(
                                  children: [
                                    const Icon(Icons.calendar_today, color: Colors.blue),
                                    const SizedBox(height: 4),
                                    Text(
                                      DateFormat('MMM d').format(DateTime.now()),
                                      style: const TextStyle(fontWeight: FontWeight.bold),
                                    ),
                                    const Text('Өнөөдөр', style: TextStyle(fontSize: 12)),
                                  ],
                                ),
                                Column(
                                  children: [
                                    const Icon(Icons.people, color: Colors.green),
                                    const SizedBox(height: 4),
                                    const Text('1', style: TextStyle(fontWeight: FontWeight.bold)),
                                    const Text('Идэвхтэй', style: TextStyle(fontSize: 12)),
                                  ],
                                ),
                                Column(
                                  children: [
                                    const Icon(Icons.trending_up, color: Colors.orange),
                                    const SizedBox(height: 4),
                                    Text(
                                      _overviewData?['overview']['assessment_trend'] != null
                                          ? '${_overviewData!['overview']['assessment_trend']['percentage'].toStringAsFixed(1)}%'
                                          : '0%',
                                      style: const TextStyle(fontWeight: FontWeight.bold),
                                    ),
                                    Text(
                                      _overviewData?['overview']['assessment_trend']?['direction'] == 'up'
                                          ? 'Өсөлт'
                                          : 'Бууралт',
                                      style: const TextStyle(fontSize: 12),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.pushNamed(context, '/questionnaires');
        },
        child: const Icon(Icons.add),
        tooltip: 'Шинэ үнэлгээ',
      ),
    );
  }
}