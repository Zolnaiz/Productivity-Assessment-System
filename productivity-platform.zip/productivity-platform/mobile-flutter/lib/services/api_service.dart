import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  static final ApiService _instance = ApiService._internal();
  factory ApiService() => _instance;
  ApiService._internal();

  final Dio _dio = Dio();
  final FlutterSecureStorage _storage = const FlutterSecureStorage();
  
  static const String baseUrl = 'http://localhost:3000/api';
  
  Future<void> initialize() async {
    // Configure Dio
    _dio.options.baseUrl = baseUrl;
    _dio.options.connectTimeout = const Duration(seconds: 30);
    _dio.options.receiveTimeout = const Duration(seconds: 30);
    
    // Add interceptors
    _dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) async {
        final token = await _storage.read(key: 'access_token');
        if (token != null) {
          options.headers['Authorization'] = 'Bearer $token';
        }
        return handler.next(options);
      },
      onError: (error, handler) async {
        if (error.response?.statusCode == 401) {
          // Token expired, try to refresh
          final refreshed = await _refreshToken();
          if (refreshed) {
            // Retry the request
            return handler.resolve(await _dio.fetch(error.requestOptions));
          }
        }
        return handler.next(error);
      },
    ));
  }
  
  Future<bool> _refreshToken() async {
    try {
      final refreshToken = await _storage.read(key: 'refresh_token');
      final response = await _dio.post('/auth/refresh', data: {
        'refresh_token': refreshToken,
      });
      
      await _storage.write(
        key: 'access_token',
        value: response.data['access_token'],
      );
      return true;
    } catch (e) {
      return false;
    }
  }
  
  // Auth methods
  Future<Map<String, dynamic>> login(String email, String password) async {
    final response = await _dio.post('/auth/login', data: {
      'email': email,
      'password': password,
    });
    
    await _storage.write(
      key: 'access_token',
      value: response.data['access_token'],
    );
    await _storage.write(
      key: 'refresh_token',
      value: response.data['refresh_token'],
    );
    
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('user', json.encode(response.data['user']));
    
    return response.data;
  }
  
  Future<void> logout() async {
    await _storage.delete(key: 'access_token');
    await _storage.delete(key: 'refresh_token');
    
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('user');
  }
  
  Future<Map<String, dynamic>> getUserProfile() async {
    final response = await _dio.get('/auth/profile');
    return response.data;
  }
  
  // Questionnaires
  Future<List<dynamic>> getQuestionnaires() async {
    final response = await _dio.get('/questionnaires');
    return response.data;
  }
  
  Future<Map<String, dynamic>> getQuestionnaire(String id) async {
    final response = await _dio.get('/questionnaires/$id');
    return response.data;
  }
  
  Future<Map<String, dynamic>> submitResponse(
    String questionnaireId,
    Map<String, dynamic> answers,
  ) async {
    final response = await _dio.post('/responses', data: {
      'questionnaireId': questionnaireId,
      'answers': answers,
    });
    return response.data;
  }
  
  // Expenses
  Future<List<dynamic>> getExpenses() async {
    final response = await _dio.get('/expenses');
    return response.data;
  }
  
  Future<Map<String, dynamic>> createExpense(Map<String, dynamic> data) async {
    final response = await _dio.post('/expenses', data: data);
    return response.data;
  }
  
  Future<Map<String, dynamic>> updateExpense(
    String id,
    Map<String, dynamic> data,
  ) async {
    final response = await _dio.put('/expenses/$id', data: data);
    return response.data;
  }
  
  Future<void> deleteExpense(String id) async {
    await _dio.delete('/expenses/$id');
  }
  
  // Reports
  Future<List<dynamic>> getReports() async {
    final response = await _dio.get('/reports');
    return response.data;
  }
  
  Future<Map<String, dynamic>> generateReport(String type) async {
    final response = await _dio.post('/reports/generate', data: {
      'type': type,
    });
    return response.data;
  }
}